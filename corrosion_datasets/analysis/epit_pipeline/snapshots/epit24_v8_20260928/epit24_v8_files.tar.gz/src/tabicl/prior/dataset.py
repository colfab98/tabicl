"""
The module offers a flexible framework for creating diverse, realistic tabular datasets
with controlled properties, which can be used for training and evaluating in-context
learning models. Key features include:

- Controlled feature relationships and causal structures via multiple generation methods
- Customizable feature distributions with mixed continuous and categorical variables
- Flexible train/test splits optimized for in-context learning evaluation
- Batch generation capabilities with hierarchical parameter sharing
- Memory-efficient handling of variable-length datasets

The main class is PriorDataset, which provides an iterable interface for generating
an infinite stream of synthetic datasets with diverse characteristics.
"""

from __future__ import annotations

import os
import sys
import math
import warnings
from dataclasses import dataclass, field
from typing import Dict, Tuple, Union, Optional, Any

import numpy as np
from scipy.stats import loguniform
import joblib

import torch
import torch.nn.functional as F
from torch import Tensor
from torch.nested import nested_tensor
from torch.utils.data import IterableDataset, get_worker_info

from .mlp_scm import MLPSCM
from .tree_scm import TreeSCM

from .hp_sampling import HpSamplerList
from .reg2cls import Reg2Cls
from .prior_config import DEFAULT_FIXED_HP, DEFAULT_SAMPLED_HP
from .target_variation import sample_coefficients
from .epit_composition_profile import (
    EPIT_COMPOSITION_PROFILE,
    EpitCompositionBatch,
    load_epit_composition_profile,
    map_epit_latents_to_compositions,
)
from .epit_feature_generator import EpitFeatureBatch, sample_epit_feature_rows
from .epit_feature_profile import EPIT_FEATURE_PROFILE, load_epit_feature_profile
from .epit_schema import epit_feature_slices
from .magpie_features import (
    EPIT_BASE_FEATURE_COUNT,
    EPIT_MATERIAL_FEATURE_COUNT,
    EPIT_MAGPIE_TOTAL_FEATURE_COUNT,
    append_magpie_descriptors_torch,
)


warnings.filterwarnings(
    "ignore", message=".*The PyTorch API of nested tensors is in prototype stage.*", category=UserWarning
)


EPIT_TARGET_RULE_COEFFICIENTS: Dict[str, Dict[str, float]] = {
    "pren_linear": {
        "material_passivity": 0.5653310250383062,
        "environment_aggressiveness": 0.43466897496169377,
        "material_chloride_interaction": 0.0,
    },
    "cr_mow_synergy": {
        "material_passivity": 0.45956446149953445,
        "environment_aggressiveness": 0.11151119774870306,
        "material_chloride_interaction": 0.13912063464595828,
        "temperature_chloride_interaction": 0.2898037061058043,
    },
    "threshold_saturation": {
        "material_passivity": 0.45702896469586524,
        "environment_aggressiveness": 0.16001595621269665,
        "material_chloride_interaction": 0.11142174308575617,
        "temperature_chloride_interaction": 0.27153333600568197,
    },
    "improved_environment": {
        "material_passivity": 0.530255964316155,
        "log_chloride_aggressiveness": 0.23456636817918805,
        "high_temperature_aggressiveness": 0.07250485977655058,
        "temperature_chloride_interaction": 0.16267280772810647,
        "acidic_ph_aggressiveness": 0.0,
    },
    "coupled_breakdown": {
        "material_passivity": 0.400022445097356,
        "coupled_environment_breakdown": 0.502545401041832,
        "acidic_ph_aggressiveness": 0.09743215386081203,
    },
    "fe_ni_cr_threshold": {
        "material_passivity": 0.5110080270672297,
        "log_chloride_aggressiveness": 0.2653108305738243,
        "high_temperature_aggressiveness": 0.10548016669329978,
        "temperature_chloride_interaction": 0.11820097566564641,
        "acidic_ph_aggressiveness": 0.0,
    },
    "method_aware": {
        "material_passivity": 0.31521453539344163,
        "environment_aggressiveness": 0.02012990784404018,
        "material_chloride_interaction": 0.2683200863035855,
        "temperature_chloride_interaction": 0.22199285038776748,
        "test_method_correction": 0.17434262007116513,
    },
}


EPIT_FE_NI_FAMILY_NAMES = ("fe", "ni_cr_mo")
EPIT_FE_NI_FAMILY_PROBS = (411.0 / 452.0, 41.0 / 452.0)
EPIT_FE_FAMILY_ID = 0
EPIT_NI_CR_MO_FAMILY_ID = 1


@dataclass
class PittingProfileInfo:
    """Role metadata for pitting-potential synthetic feature profiles."""

    applied: bool = False
    material_style: str = "latent"
    role_columns: Dict[str, list[int]] = field(default_factory=dict)
    categorical_columns: list[int] = field(default_factory=list)
    material_passivity: Optional[Tensor] = None
    material_susceptibility: Optional[Tensor] = None
    physical_profile_applied: bool = False
    environment_aggressiveness: Optional[Tensor] = None
    process_offset: Optional[Tensor] = None
    exposure_damage: Optional[Tensor] = None
    descriptor_signal: Optional[Tensor] = None
    intervention_signal: Optional[Tensor] = None
    material_family_ids: Optional[Tensor] = None

    def add_role(self, role: str, col: int, *, categorical: bool = False) -> None:
        self.role_columns.setdefault(role, []).append(col)
        if categorical:
            self.categorical_columns.append(col)


@dataclass(frozen=True)
class EpitLatentSCMContext:
    """Internal feature layouts for latent-SCM composition expansion."""

    family: str
    output_blocks: Dict[str, slice]
    latent_blocks: Dict[str, slice]
    scm_num_features: int


@dataclass
class InhibitorEfficiencyProfileInfo:
    """Role metadata for inhibitor-efficiency synthetic feature profiles."""

    applied: bool = False
    role_columns: Dict[str, list[int]] = field(default_factory=dict)
    categorical_columns: list[int] = field(default_factory=list)
    descriptor_efficacy: Optional[Tensor] = None
    environment_modifier: Optional[Tensor] = None
    material_modifier: Optional[Tensor] = None
    intervention_signal: Optional[Tensor] = None

    def add_role(self, role: str, col: int, *, categorical: bool = False) -> None:
        self.role_columns.setdefault(role, []).append(col)
        if categorical:
            self.categorical_columns.append(col)


class Prior:
    """Abstract base class for dataset prior generators.

    Defines the interface and common functionality for different types of
    synthetic dataset generators.

    Parameters
    ----------
    batch_size : int, default=256
        Total number of datasets to generate per batch.

    min_features : int, default=2
        Minimum number of features per dataset.

    max_features : int, default=100
        Maximum number of features per dataset.

    max_classes : int, default=10
        Maximum number of target classes.

    min_seq_len : int, optional
        Minimum samples per dataset. If None, uses max_seq_len.

    max_seq_len : int, default=1024
        Maximum samples per dataset.

    log_seq_len : bool, default=False
        If True, sample sequence length from a log-uniform distribution.

    min_train_size : int or float, default=0.1
        Position or ratio for train/test split start. If int, absolute position.
        If float between 0 and 1, specifies a fraction of sequence length.

    max_train_size : int or float, default=0.9
        Position or ratio for train/test split end. If int, absolute position.
        If float between 0 and 1, specifies a fraction of sequence length.

    replay_small : bool, default=False
        If True, occasionally sample smaller sequence lengths with
        specific distributions to ensure model robustness on smaller datasets.
    """

    def __init__(
        self,
        batch_size: int = 256,
        min_features: int = 2,
        max_features: int = 100,
        max_classes: int = 10,
        min_seq_len: Optional[int] = None,
        max_seq_len: int = 1024,
        log_seq_len: bool = False,
        min_train_size: Union[int, float] = 0.1,
        max_train_size: Union[int, float] = 0.9,
        replay_small: bool = False,
    ):
        self.batch_size = batch_size

        assert min_features <= max_features, "Invalid feature range"
        self.min_features = min_features
        self.max_features = max_features

        if max_classes < 0 or max_classes == 1:
            raise ValueError("max_classes must be 0 for regression or >= 2 for classification.")
        self.max_classes = max_classes
        self.min_seq_len = min_seq_len
        self.max_seq_len = max_seq_len
        self.log_seq_len = log_seq_len

        self.validate_train_size_range(min_train_size, max_train_size)
        self.min_train_size = min_train_size
        self.max_train_size = max_train_size
        self.replay_small = replay_small

    @staticmethod
    def validate_train_size_range(min_train_size: Union[int, float], max_train_size: Union[int, float]) -> None:
        """Check if the training size range is valid.

        Parameters
        ----------
        min_train_size : int or float
            Minimum training size (position or ratio).

        max_train_size : int or float
            Maximum training size (position or ratio).

        Raises
        ------
        AssertionError
            If training size range is invalid.

        ValueError
            If training size types are mismatched or invalid.
        """
        # Check for numeric types only
        if not isinstance(min_train_size, (int, float)) or not isinstance(max_train_size, (int, float)):
            raise TypeError("Training sizes must be int or float")

        # Check for valid ranges based on type
        if isinstance(min_train_size, int) and isinstance(max_train_size, int):
            assert 0 < min_train_size < max_train_size, "0 < min_train_size < max_train_size"
        elif isinstance(min_train_size, float) and isinstance(max_train_size, float):
            assert 0 < min_train_size < max_train_size < 1, "0 < min_train_size < max_train_size < 1"
        else:
            raise ValueError("Both training sizes must be of the same type (int or float)")

    @staticmethod
    def sample_seq_len(
        min_seq_len: Optional[int], max_seq_len: int, log: bool = False, replay_small: bool = False
    ) -> int:
        """Select a random sequence length within the specified range.

        This method provides flexible sampling strategies for dataset sizes, including
        occasional re-sampling of smaller sequence lengths for better training diversity.

        Parameters
        ----------
        min_seq_len : int, optional
            Minimum sequence length. If None, returns max_seq_len directly.

        max_seq_len : int
            Maximum sequence length.

        log : bool, default=False
            If True, sample from a log-uniform distribution to better
            cover the range of possible sizes.

        replay_small : bool, default=False
            If True, occasionally sample smaller sequence lengths with
            specific distributions to ensure model robustness on smaller datasets.

        Returns
        -------
        int
            The sampled sequence length.
        """
        if min_seq_len is None:
            return max_seq_len

        if log:
            seq_len = int(loguniform.rvs(min_seq_len, max_seq_len))
        else:
            seq_len = np.random.randint(min_seq_len, max_seq_len)

        if replay_small:
            p = np.random.random()
            if p < 0.05:
                return np.random.randint(200, 1000)
            elif p < 0.3:
                return int(loguniform.rvs(1000, 10000))
            else:
                return seq_len
        else:
            return seq_len

    @staticmethod
    def sample_train_size(min_train_size: Union[int, float], max_train_size: Union[int, float], seq_len: int) -> int:
        """Select a random training size within the specified range.

        This method handles both absolute position and fractional ratio approaches
        for determining the training/test split point.

        Parameters
        ----------
        min_train_size : int or float
            Minimum training size. If int, used as absolute position.
            If float between 0 and 1, used as ratio of sequence length.

        max_train_size : int or float
            Maximum training size. If int, used as absolute position.
            If float between 0 and 1, used as ratio of sequence length.

        seq_len : int
            Total sequence length.

        Returns
        -------
        int
            The sampled training size position.

        Raises
        ------
        ValueError
            If training size range has incompatible types.
        """
        if isinstance(min_train_size, int) and isinstance(max_train_size, int):
            train_size = np.random.randint(min_train_size, max_train_size)
        elif isinstance(min_train_size, float) and isinstance(min_train_size, float):
            train_size = np.random.uniform(min_train_size, max_train_size)
            train_size = int(seq_len * train_size)
        else:
            raise ValueError("Invalid training size range.")
        return train_size

    @staticmethod
    def adjust_max_features(seq_len: int, max_features: int) -> int:
        """Adjust the maximum number of features based on the sequence length.

        This method implements an adaptive feature limit that scales inversely
        with sequence length. Longer sequences are restricted to fewer features
        to prevent memory issues and excessive computation times while still
        maintaining dataset diversity and learning difficulty.

        Parameters
        ----------
        seq_len : int
            Sequence length (number of samples).

        max_features : int
            Original maximum number of features.

        Returns
        -------
        int
            Adjusted maximum number of features, ensuring computational feasibility.
        """
        if seq_len <= 10240:
            return min(100, max_features)
        elif 10240 < seq_len <= 20000:
            return min(80, max_features)
        elif 20000 < seq_len <= 30000:
            return min(60, max_features)
        elif 30000 < seq_len <= 40000:
            return min(40, max_features)
        elif 40000 < seq_len <= 50000:
            return min(30, max_features)
        elif 50000 < seq_len <= 60000:
            return min(20, max_features)
        elif 60000 < seq_len <= 65000:
            return min(15, max_features)
        else:
            return 10

    @staticmethod
    def delete_unique_features(X: Tensor, d: Tensor) -> Tuple[Tensor, Tensor]:
        """Remove features that have only one unique value across all samples.

        Single-value features provide no useful information for learning since they
        have zero variance. This method identifies and removes such constant features
        to improve model training efficiency and stability. The removed features are
        replaced with zero padding to maintain tensor dimensions.

        Parameters
        ----------
        X : Tensor
            Input features tensor of shape ``(B, T, H)`` where B is batch size,
            T is sequence length, and H is feature dimensionality.

        d : Tensor
            Number of features per dataset of shape ``(B,)``, indicating how many
            features are actually used in each dataset (rest is padding).

        Returns
        -------
        X_new : Tensor
            The filtered tensor with non-informative features removed.

        d_new : Tensor
            The updated feature count per dataset.
        """

        def filter_unique_features(xi: Tensor, di: int) -> Tuple[Tensor, Tensor]:
            """Filters features with only one unique value from a single dataset."""
            num_features = xi.shape[-1]
            # Only consider actual features (up to di, ignoring padding)
            xi = xi[:, :di]
            # Identify features with more than one unique value (informative features)
            unique_mask = [len(torch.unique(xi[:, j])) > 1 for j in range(di)]
            di_new = sum(unique_mask)
            # Create new tensor with only informative features, padding the rest
            xi_new = F.pad(xi[:, unique_mask], pad=(0, num_features - di_new), mode="constant", value=0)
            return xi_new, torch.tensor(di_new, device=xi.device)

        # Process each dataset in the batch independently
        filtered_results = [filter_unique_features(xi, di) for xi, di in zip(X, d)]
        X_new, d_new = [torch.stack(res) for res in zip(*filtered_results)]

        return X_new, d_new

    @staticmethod
    def sanity_check(X: Tensor, y: Tensor, train_size: int, n_attempts: int = 10, min_classes: int = 2) -> bool:
        """Verify that both train and test sets contain all classes.

        For in-context learning to work properly, we need both the train and test
        sets to contain examples from all classes. This method checks this condition
        and attempts to fix invalid splits by randomly permuting the data.

        Parameters
        ----------
        X : Tensor
            Input features tensor of shape ``(B, T, H)``.

        y : Tensor
            Target labels tensor of shape ``(B, T)``.

        train_size : int
            Position to split the data into train and test sets.

        n_attempts : int, default=10
            Number of random permutations to try for fixing invalid splits.

        min_classes : int, default=2
            Minimum number of classes required in both train and test sets.

        Returns
        -------
        bool
            True if all datasets have valid splits, False otherwise.
        """

        def is_valid_split(yi: Tensor) -> bool:
            """Check if a single dataset has a valid train/test split."""
            # Guard against invalid train_size
            if train_size <= 0 or train_size >= yi.shape[0]:
                return False

            # A valid split requires both train and test sets to have the same classes
            # and at least min_classes different classes must be present
            unique_tr = torch.unique(yi[:train_size])
            unique_te = torch.unique(yi[train_size:])
            return set(unique_tr.tolist()) == set(unique_te.tolist()) and len(unique_tr) >= min_classes

        # Check each dataset in the batch
        for i, (xi, yi) in enumerate(zip(X, y)):
            if is_valid_split(yi):
                continue

            # If the dataset has an invalid split, try to fix it with random permutations
            succeeded = False
            for _ in range(n_attempts):
                # Generate a random permutation of the samples
                perm = torch.randperm(yi.shape[0])
                yi_perm = yi[perm]
                xi_perm = xi[perm]
                # Check if the permutation results in a valid split
                if is_valid_split(yi_perm):
                    X[i], y[i] = xi_perm, yi_perm
                    succeeded = True
                    break

            if not succeeded:  # No valid split was found after all attempts
                return False

        return True

    @staticmethod
    def regression_sanity_check(
        X: Tensor,
        y: Tensor,
        train_size: int,
        n_attempts: int = 10,
        min_unique: int = 2,
        min_std: float = 1e-6,
    ) -> bool:
        """Verify that regression train and test splits contain usable targets."""

        def is_valid_split(yi: Tensor) -> bool:
            if train_size <= 0 or train_size >= yi.shape[0]:
                return False
            if not torch.isfinite(yi).all():
                return False

            y_train = yi[:train_size]
            y_test = yi[train_size:]
            if torch.unique(y_train).numel() < min_unique or torch.unique(y_test).numel() < min_unique:
                return False

            return bool(
                torch.std(y_train.float(), unbiased=False) > min_std
                and torch.std(y_test.float(), unbiased=False) > min_std
            )

        for i, (xi, yi) in enumerate(zip(X, y)):
            if is_valid_split(yi):
                continue

            succeeded = False
            for _ in range(n_attempts):
                perm = torch.randperm(yi.shape[0], device=yi.device)
                yi_perm = yi[perm]
                xi_perm = xi[perm]
                if is_valid_split(yi_perm):
                    X[i], y[i] = xi_perm, yi_perm
                    succeeded = True
                    break

            if not succeeded:
                return False

        return True


class SCMPrior(Prior):
    """Generate synthetic datasets using Structural Causal Models (SCM).

    The data generation process follows a hierarchical structure:

    1. Generate a list of parameters for each dataset, respecting group/subgroup sharing.
    2. Process the parameter list to generate datasets, applying necessary
       transformations and checks.

    Parameters
    ----------
    batch_size : int, default=256
        Total number of datasets to generate per batch.

    batch_size_per_gp : int, default=4
        Number of datasets per group, sharing similar characteristics.

    batch_size_per_subgp : int, optional
        Number of datasets per subgroup, with more similar causal structures.
        If None, defaults to batch_size_per_gp.

    min_features : int, default=2
        Minimum number of features per dataset.

    max_features : int, default=100
        Maximum number of features per dataset.

    max_classes : int, default=10
        Maximum number of target classes.

    min_seq_len : int, optional
        Minimum samples per dataset. If None, uses max_seq_len directly.

    max_seq_len : int, default=1024
        Maximum samples per dataset.

    log_seq_len : bool, default=False
        If True, sample sequence length from a log-uniform distribution.

    seq_len_per_gp : bool, default=False
        If True, sample sequence length per group, allowing variable-sized datasets.

    min_train_size : int or float, default=0.1
        Position or ratio for train/test split start. If int, absolute position.
        If float between 0 and 1, specifies a fraction of sequence length.

    max_train_size : int or float, default=0.9
        Position or ratio for train/test split end. If int, absolute position.
        If float between 0 and 1, specifies a fraction of sequence length.

    replay_small : bool, default=False
        If True, occasionally sample smaller sequence lengths with
        specific distributions to ensure model robustness on smaller datasets.

    prior_type : str, default="mlp_scm"
        Type of prior: 'mlp_scm' (default), 'tree_scm', or 'mix_scm'.
        'mix_scm' randomly selects between 'mlp_scm' and 'tree_scm' based on
        probabilities.

    fixed_hp : dict, default=DEFAULT_FIXED_HP
        Fixed structural configuration parameters.

    sampled_hp : dict, default=DEFAULT_SAMPLED_HP
        Parameters sampled during generation.

    n_jobs : int, default=-1
        Number of parallel jobs to run (-1 means using all processors).

    num_threads_per_generate : int, default=1
        Number of threads per job for dataset generation.

    device : str, default="cpu"
        Computation device ('cpu' or 'cuda').
    """

    def __init__(
        self,
        batch_size: int = 256,
        batch_size_per_gp: int = 4,
        batch_size_per_subgp: Optional[int] = None,
        min_features: int = 2,
        max_features: int = 100,
        max_classes: int = 10,
        min_seq_len: Optional[int] = None,
        max_seq_len: int = 1024,
        log_seq_len: bool = False,
        seq_len_per_gp: bool = False,
        min_train_size: Union[int, float] = 0.1,
        max_train_size: Union[int, float] = 0.9,
        replay_small: bool = False,
        prior_type: str = "mlp_scm",
        fixed_hp: Dict[str, Any] = DEFAULT_FIXED_HP,
        sampled_hp: Dict[str, Any] = DEFAULT_SAMPLED_HP,
        n_jobs: int = -1,
        num_threads_per_generate: int = 1,
        informed_prior_ratio: float = 0.5,
        device: str = "cpu",
    ):
        super().__init__(
            batch_size=batch_size,
            min_features=min_features,
            max_features=max_features,
            max_classes=max_classes,
            min_seq_len=min_seq_len,
            max_seq_len=max_seq_len,
            log_seq_len=log_seq_len,
            min_train_size=min_train_size,
            max_train_size=max_train_size,
            replay_small=replay_small,
        )

        self.batch_size_per_gp = batch_size_per_gp
        self.batch_size_per_subgp = batch_size_per_subgp or batch_size_per_gp
        self.seq_len_per_gp = seq_len_per_gp
        self.prior_type = prior_type
        self.fixed_hp = fixed_hp
        self.sampled_hp = sampled_hp
        self.n_jobs = n_jobs
        self.num_threads_per_generate = num_threads_per_generate
        if not 0.0 <= informed_prior_ratio <= 1.0:
            raise ValueError("informed_prior_ratio must be in [0, 1].")
        self.informed_prior_ratio = informed_prior_ratio
        self.device = device
        self.last_pitting_target_rule: Optional[Dict[str, Any]] = None
        self.last_pitting_target_component: Optional[Tensor] = None
        self.last_pitting_target_drive: Optional[Tensor] = None
        self.last_pitting_composition_batch: Optional[EpitCompositionBatch] = None
        self.last_pitting_feature_batch: Optional[EpitFeatureBatch] = None
        self.last_pitting_material_family_ids: Optional[Tensor] = None
        self.last_pitting_scm_target_input: Optional[Tensor] = None
        self.last_pitting_scm_target_metadata: Optional[Dict[str, Any]] = None
        self.coefficient_variation = float(fixed_hp.get("pitting_coefficient_variation", 0.0))
        if not np.isfinite(self.coefficient_variation) or not 0 <= self.coefficient_variation < 1:
            raise ValueError("pitting_coefficient_variation must be in [0, 1).")
        self._coefficient_rng = None
        self._coefficient_worker_seed = None
        if self.coefficient_variation:
            if fixed_hp.get("pitting_composition_mode") != "empirical_features_scm_target" or n_jobs != 1:
                raise ValueError("Coefficient variation requires empirical_features_scm_target and n_jobs=1.")
            bounds = fixed_hp.get("pitting_coefficient_upper_bounds")
            overrides = self._fixed_epit_target_rule_coefficient_overrides()
            if not isinstance(bounds, dict) or not overrides or set(bounds) != set(overrides):
                raise ValueError("Coefficient variation requires explicit calibrated coefficients and matching upper bounds.")
            self._coefficient_rng = np.random.default_rng(fixed_hp.get("pitting_coefficient_variation_seed", 42))
            for family, values in overrides.items():
                sample_coefficients(values, 0, self._coefficient_rng, upper_bounds=bounds[family])

    def hp_sampling(self) -> Dict[str, Any]:
        """Sample hyperparameters for dataset generation.

        Returns
        -------
        dict
            Dictionary with sampled hyperparameters merged with fixed ones.
        """
        hp_sampler = HpSamplerList(self.sampled_hp, device=self.device)
        return hp_sampler.sample()

    @staticmethod
    def _normalize_two_way_probs(probs: Any, fallback: Tuple[float, float]) -> np.ndarray:
        """Normalize and validate a two-way probability vector."""
        raw = probs if probs is not None else fallback
        values = np.array(raw, dtype=float).reshape(-1)
        if values.size != 2:
            values = np.array(fallback, dtype=float)
        values = np.clip(values, a_min=0.0, a_max=None)
        total = values.sum()
        if total <= 0:
            values = np.array(fallback, dtype=float)
            total = values.sum()
        return values / total

    def _get_prior_mix_probs(self, informed: bool = False) -> np.ndarray:
        """Return sampling probabilities for (mlp_scm, tree_scm)."""
        if informed:
            return self._normalize_two_way_probs(self.fixed_hp.get("informed_mix_probs"), fallback=(0.9, 0.1))
        return self._normalize_two_way_probs(self.fixed_hp.get("mix_probs"), fallback=(0.7, 0.3))

    @staticmethod
    def _rank_uniform(values: Tensor) -> Tensor:
        """Map a latent feature column to empirical quantiles in (0, 1)."""
        if values.numel() <= 1:
            return torch.full_like(values, 0.5)
        clean = torch.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0)
        order = torch.argsort(clean)
        ranks = torch.empty_like(clean)
        ranks[order] = torch.arange(1, clean.numel() + 1, device=clean.device, dtype=clean.dtype)
        return ranks / float(clean.numel() + 1)

    @staticmethod
    def _log_uniform_from_rank(u: Tensor, low: float, high: float) -> Tensor:
        return torch.exp(math.log(low) + u * (math.log(high) - math.log(low)))

    @staticmethod
    def _normal_from_rank(u: Tensor) -> Tensor:
        return math.sqrt(2.0) * torch.erfinv(2.0 * u - 1.0)

    @staticmethod
    def _piecewise_ph_from_rank(u: Tensor) -> Tensor:
        acidic = (u / 0.20).clamp(0.0, 1.0) * 6.0
        near_neutral = 6.0 + ((u - 0.20) / 0.60).clamp(0.0, 1.0) * 3.0
        alkaline = 9.0 + ((u - 0.80) / 0.20).clamp(0.0, 1.0) * 5.0
        return torch.where(u < 0.20, acidic, torch.where(u < 0.80, near_neutral, alkaline))

    @classmethod
    def _corrosion_marginal_values(cls, values: Tensor, family: str) -> Tensor:
        """Transform one latent column into a broad corrosion-like marginal family."""
        u = cls._rank_uniform(values).clamp(1e-6, 1.0 - 1e-6)

        if family == "ph":
            return cls._piecewise_ph_from_rank(u)
        if family == "chloride":
            return cls._log_uniform_from_rank(u, 1e-3, 1e5)
        if family == "concentration":
            return cls._log_uniform_from_rank(u, 1e-6, 1e1)
        if family == "salinity":
            return cls._log_uniform_from_rank(u, 1e-3, 3.5e1)
        if family == "temperature":
            return -10.0 + 130.0 * u
        if family == "potential":
            return -1.5 + 3.0 * u
        if family == "current_density":
            return cls._log_uniform_from_rank(u, 1e-9, 1e-1)
        if family == "resistance":
            return cls._log_uniform_from_rank(u, 1e-2, 1e6)
        if family == "exposure_time":
            return cls._log_uniform_from_rank(u, 1e-2, 1e5)
        if family == "cycle_count":
            return torch.floor(cls._log_uniform_from_rank(u, 1.0, 1e6))
        if family == "material_fraction":
            return 100.0 * u
        if family == "material_bounded":
            return u
        if family == "material_property":
            return cls._log_uniform_from_rank(u, 1e-2, 1e3)
        if family == "material_category":
            n_categories = int(np.random.choice([2, 3, 4, 5]))
            return torch.floor(u * n_categories).clamp(max=n_categories - 1)
        if family == "environment_bounded":
            return u
        if family == "environment_category":
            n_categories = int(np.random.choice([2, 3, 4, 5, 6]))
            return torch.floor(u * n_categories).clamp(max=n_categories - 1)
        if family == "prior_damage":
            return u
        if family == "process_binary":
            return (u > 0.5).to(dtype=values.dtype)
        if family == "process_category":
            n_categories = int(np.random.choice([2, 3, 4, 5, 6]))
            return torch.floor(u * n_categories).clamp(max=n_categories - 1)
        if family == "process_score":
            return u
        if family == "intervention_binary":
            return (u > 0.5).to(dtype=values.dtype)
        if family == "intervention_category":
            n_categories = int(np.random.choice([2, 3, 4]))
            return torch.floor(u * n_categories).clamp(max=n_categories - 1)
        if family == "intervention_dose":
            return u
        if family == "descriptor_standard":
            scale = float(np.random.uniform(0.5, 3.0))
            shift = float(np.random.uniform(-1.0, 1.0))
            return shift + scale * cls._normal_from_rank(u)
        if family == "descriptor_positive":
            return cls._log_uniform_from_rank(u, 1e-3, 1e3)
        if family == "descriptor_count":
            return torch.floor(cls._log_uniform_from_rank(u, 1.0, 256.0))
        if family == "descriptor_bounded":
            return u

        raise ValueError(f"Unknown corrosion marginal family: {family}")

    @staticmethod
    def _apply_composition_marginal(X: Tensor, feature_slice: slice) -> None:
        width = feature_slice.stop - feature_slice.start
        if width <= 1:
            return
        logits = torch.nan_to_num(X[:, feature_slice], nan=0.0, posinf=0.0, neginf=0.0)
        sharpness = float(np.random.uniform(0.6, 1.8))
        X[:, feature_slice] = torch.softmax(logits * sharpness, dim=-1) * 100.0

    def _informed_physical_marginal_profile(self) -> str:
        profile = str(self.fixed_hp.get("informed_physical_marginal_profile", "corrosion_broad")).strip().lower()
        profile = profile.replace("-", "_")
        aliases = {
            "pitting": "pitting_potential_v1",
            "epit": "pitting_potential_v1",
            "pitting_potential": "pitting_potential_v1",
            "pitting_potential_profile": "pitting_potential_v1",
            "datacor": "inhibitor_efficiency_v1",
            "inhibitor": "inhibitor_efficiency_v1",
            "inhibitor_efficiency": "inhibitor_efficiency_v1",
            "inhibition_efficiency": "inhibitor_efficiency_v1",
            "inhibitor_efficiency_profile": "inhibitor_efficiency_v1",
        }
        return aliases.get(profile, profile)

    @staticmethod
    def _is_pitting_profile_name(profile: str) -> bool:
        return profile in {"pitting_potential_v1", "pitting_v1", "epit_v1"}

    @staticmethod
    def _is_inhibitor_efficiency_profile_name(profile: str) -> bool:
        return profile in {"inhibitor_efficiency_v1", "inhibitor_v1", "datacor_v1"}

    @classmethod
    def _categorical_values_from_rank(cls, values: Tensor, n_categories: int) -> Tensor:
        u = cls._rank_uniform(values).clamp(0.0, 1.0 - 1e-6)
        return torch.floor(u * n_categories).clamp(max=n_categories - 1)


    def _fixed_epit_schema_enabled(self) -> bool:
        return bool(self.fixed_hp.get("pitting_fixed_epit_schema", False))

    def _pitting_magpie_features_enabled(self) -> bool:
        return bool(self.fixed_hp.get("pitting_magpie_features", False))

    def _pitting_magpie_base_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Use the fixed physical features before optional informed-task descriptors."""

        if not self._pitting_magpie_features_enabled():
            return params
        if int(params["num_features"]) != EPIT_MAGPIE_TOTAL_FEATURE_COUNT:
            raise ValueError(
                "pitting_magpie_features requires "
                f"num_features={EPIT_MAGPIE_TOTAL_FEATURE_COUNT}, got {params['num_features']}."
            )
        if int(params["max_features"]) < EPIT_MAGPIE_TOTAL_FEATURE_COUNT:
            raise ValueError(
                "pitting_magpie_features requires "
                f"max_features>={EPIT_MAGPIE_TOTAL_FEATURE_COUNT}."
            )
        base_params = {**params, "num_features": EPIT_BASE_FEATURE_COUNT}
        if not params.get("informed_mode", False):
            return base_params
        if not self._fixed_epit_schema_enabled():
            raise ValueError("pitting_magpie_features requires pitting_fixed_epit_schema=True.")
        if not self._is_pitting_profile_name(self._informed_physical_marginal_profile()):
            raise ValueError("pitting_magpie_features requires the pitting_potential_v1 profile.")
        if self._informed_target_family() != "pitting_potential":
            raise ValueError("pitting_magpie_features requires informed_target_family='pitting_potential'.")
        if float(self.fixed_hp.get("informed_physical_marginal_prob", 0.0)) != 1.0:
            raise ValueError("pitting_magpie_features requires informed_physical_marginal_prob=1.")

        style_probs = np.asarray(self.fixed_hp.get("pitting_material_style_probs"), dtype=float)
        if style_probs.shape != (5,) or not np.allclose(style_probs, (1.0, 0.0, 0.0, 0.0, 0.0)):
            raise ValueError("pitting_magpie_features requires composition-like material style only.")
        return base_params

    def _pitting_composition_mode(self) -> str:
        mode = str(self.fixed_hp.get("pitting_composition_mode", "legacy")).strip().lower().replace("-", "_")
        aliases = {
            "off": "legacy",
            "disabled": "legacy",
            "dataset": "empirical",
            "profile": "empirical",
            "empirical_profile": "empirical",
            "feature_profile": "empirical_features",
            "empirical_feature_profile": "empirical_features",
            "feature_profile_scm_target": "empirical_features_scm_target",
            "empirical_feature_scm_target": "empirical_features_scm_target",
        }
        mode = aliases.get(mode, mode)
        if mode not in {
            "legacy",
            "empirical",
            "empirical_features",
            "empirical_features_scm_target",
            "fe_ni_softmax",
        }:
            raise ValueError(
                "pitting_composition_mode must be 'legacy', 'empirical', "
                "'empirical_features', 'empirical_features_scm_target', or "
                "'fe_ni_softmax'."
            )
        return mode

    def _empirical_pitting_composition_enabled(self) -> bool:
        return self._pitting_composition_mode() == "empirical"

    def _empirical_pitting_feature_profile_enabled(self) -> bool:
        return self._pitting_composition_mode() in {
            "empirical_features",
            "empirical_features_scm_target",
        }

    def _empirical_pitting_scm_target_enabled(self) -> bool:
        return self._pitting_composition_mode() == "empirical_features_scm_target"

    def _fe_ni_softmax_pitting_composition_enabled(self) -> bool:
        return self._pitting_composition_mode() == "fe_ni_softmax"

    @staticmethod
    def _standardize_array(values: np.ndarray) -> np.ndarray:
        values = np.nan_to_num(np.asarray(values, dtype=float).reshape(-1), nan=0.0, posinf=0.0, neginf=0.0)
        if values.size <= 1:
            return np.zeros_like(values, dtype=float)
        centered = values - float(values.mean())
        scale = float(centered.std(ddof=0))
        if not np.isfinite(scale) or scale <= 1e-6:
            return np.zeros_like(values, dtype=float)
        return centered / scale

    @staticmethod
    def _rank_uniform_array(values: np.ndarray) -> np.ndarray:
        values = np.nan_to_num(np.asarray(values, dtype=float).reshape(-1), nan=0.0, posinf=0.0, neginf=0.0)
        if values.size <= 1:
            return np.full_like(values, 0.5, dtype=float)
        order = np.argsort(values, kind="mergesort")
        ranks = np.empty(values.size, dtype=float)
        ranks[order] = np.arange(1, values.size + 1, dtype=float)
        return ranks / float(values.size + 1)

    @staticmethod
    def _log_uniform_from_rank_array(u: np.ndarray, low: float, high: float) -> np.ndarray:
        u = np.asarray(u, dtype=float)
        return np.exp(math.log(float(low)) + u * (math.log(float(high)) - math.log(float(low))))

    @staticmethod
    def _piecewise_ph_from_rank_array(u: np.ndarray) -> np.ndarray:
        u = np.asarray(u, dtype=float)
        acidic = np.clip(u / 0.20, 0.0, 1.0) * 6.0
        near_neutral = 6.0 + np.clip((u - 0.20) / 0.60, 0.0, 1.0) * 3.0
        alkaline = 9.0 + np.clip((u - 0.80) / 0.20, 0.0, 1.0) * 5.0
        return np.where(u < 0.20, acidic, np.where(u < 0.80, near_neutral, alkaline))

    @staticmethod
    def _fixed_epit_material_anchor(width: int) -> np.ndarray:
        # Fixed EPIT material columns are Fe, Cr, Ni, Mo, W, then minor alloying elements.
        anchor = np.zeros(int(width), dtype=float)
        if int(width) > 1:
            anchor[1] = 1.0
        if int(width) > 2:
            anchor[2] = 0.25
        if int(width) > 3:
            anchor[3] = 3.3
        if int(width) > 4:
            anchor[4] = 1.65
        return anchor

    def _sample_fixed_epit_material_weights(
        self, width: int, device: torch.device, dtype: torch.dtype
    ) -> Tuple[Tensor, np.ndarray]:
        anchor_np = self._fixed_epit_material_anchor(width)
        anchor = torch.as_tensor(anchor_np, device=device, dtype=dtype)
        weights = anchor + 0.15 * torch.randn(int(width), device=device, dtype=dtype)
        for idx in (1, 2, 3, 4):
            if idx < int(width) and anchor_np[idx] > 0.0:
                weights[idx] = weights[idx].clamp_min(0.05 * float(anchor_np[idx]))
        weights = weights / torch.linalg.vector_norm(weights).clamp_min(1e-6)
        return weights, anchor_np

    def _fixed_epit_target_rule_distribution(
        self,
    ) -> Optional[Tuple[list[str], Dict[str, float], Dict[str, float]]]:
        raw_scores = self.fixed_hp.get("pitting_target_rule_scores")
        if raw_scores is None:
            return None
        if isinstance(raw_scores, dict):
            score_items = list(raw_scores.items())
        else:
            entries = [raw_scores] if isinstance(raw_scores, str) else list(raw_scores)
            score_items = []
            for entry in entries:
                name, separator, value = str(entry).partition("=")
                if not separator:
                    raise ValueError(
                        "Each pitting target-rule score must use name=score."
                    )
                score_items.append((name.strip(), value.strip()))

        scores: Dict[str, float] = {}
        for raw_name, raw_value in score_items:
            name = str(raw_name).strip()
            if name not in EPIT_TARGET_RULE_COEFFICIENTS:
                choices = ", ".join(EPIT_TARGET_RULE_COEFFICIENTS)
                raise ValueError(
                    f"Unknown pitting target rule {name!r}. Available: {choices}."
                )
            if name in scores:
                raise ValueError(f"Duplicate pitting target-rule score for {name!r}.")
            value = float(raw_value)
            if not np.isfinite(value) or value < 0.0:
                raise ValueError("Pitting target-rule scores must be finite and non-negative.")
            scores[name] = value
        if not scores or sum(scores.values()) <= 0.0:
            raise ValueError("At least one pitting target-rule score must be positive.")

        names = list(scores)
        values = np.asarray([scores[name] for name in names], dtype=float)
        probabilities = values / values.sum()
        return names, scores, {
            name: float(probability)
            for name, probability in zip(names, probabilities, strict=True)
        }

    def _sample_fixed_epit_target_rule_family(
        self,
    ) -> Optional[Tuple[str, Dict[str, float], Dict[str, float]]]:
        distribution = self._fixed_epit_target_rule_distribution()
        if distribution is None:
            return None
        names, scores, probabilities = distribution
        family = str(
            np.random.choice(
                names,
                p=np.asarray([probabilities[name] for name in names], dtype=float),
            )
        )
        return family, scores, probabilities

    def _fixed_epit_target_rule_coefficient_overrides(
        self,
    ) -> Dict[str, Dict[str, float]]:
        raw_coefficients = self.fixed_hp.get("pitting_target_rule_coefficients")
        if raw_coefficients is None:
            return {}
        entries = (
            [raw_coefficients]
            if isinstance(raw_coefficients, str)
            else list(raw_coefficients)
        )
        overrides: Dict[str, Dict[str, float]] = {}
        for entry in entries:
            key, separator, raw_value = str(entry).partition("=")
            family, term_separator, term = key.strip().partition(".")
            if not separator or not term_separator or not family or not term:
                raise ValueError(
                    "Each pitting target-rule coefficient must use "
                    "FAMILY.TERM=VALUE."
                )
            if family not in EPIT_TARGET_RULE_COEFFICIENTS:
                raise ValueError(f"Unknown pitting target rule {family!r}.")
            if term not in EPIT_TARGET_RULE_COEFFICIENTS[family]:
                raise ValueError(
                    f"Unknown coefficient {term!r} for pitting target rule "
                    f"{family!r}."
                )
            family_values = overrides.setdefault(family, {})
            if term in family_values:
                raise ValueError(f"Duplicate coefficient {family}.{term}.")
            value = float(raw_value)
            if not np.isfinite(value) or value < 0.0:
                raise ValueError(
                    "Pitting target-rule coefficients must be finite and "
                    "non-negative."
                )
            family_values[term] = value

        for family, values in overrides.items():
            expected_terms = set(EPIT_TARGET_RULE_COEFFICIENTS[family])
            if set(values) != expected_terms:
                missing = sorted(expected_terms - set(values))
                raise ValueError(
                    f"Coefficient override for {family!r} is incomplete; "
                    f"missing {missing}."
                )
            if not np.isclose(sum(values.values()), 1.0):
                raise ValueError(
                    f"Calibrated coefficients for {family!r} must sum to one."
                )
        return overrides

    def _sample_fixed_epit_target_rule(
        self,
        X: Tensor,
        blocks: Dict[str, slice],
        target_mix_weight: float,
        profile_info: Optional[PittingProfileInfo],
    ) -> Dict[str, Any]:
        material_slice = blocks.get("material")
        env_slice = blocks.get("environment")
        process_slice = blocks.get("process_history")
        if material_slice is None or material_slice.stop <= material_slice.start:
            raise ValueError("Fixed EPIT schema requires a material block.")
        if env_slice is None or env_slice.stop - env_slice.start < 3:
            raise ValueError("Fixed EPIT schema requires temperature, chloride, and pH environment columns.")
        if process_slice is None or process_slice.stop <= process_slice.start:
            raise ValueError("Fixed EPIT schema requires a process/test-method column.")

        material_width = material_slice.stop - material_slice.start
        material_weights, material_anchor_weights = self._sample_fixed_epit_material_weights(
            material_width, X.device, X.dtype
        )
        environment_weights = np.asarray(
            [
                float(np.random.uniform(0.03, 0.12)),
                float(np.random.uniform(0.75, 1.10)),
                float(np.random.uniform(0.05, 0.18)),
            ],
            dtype=float,
        )
        process_count = self.fixed_hp.get("pitting_process_category_count")
        if process_count is None and self._empirical_pitting_feature_profile_enabled():
            feature_profile_name = str(
                self.fixed_hp.get("pitting_feature_profile", EPIT_FEATURE_PROFILE)
            )
            feature_profile = load_epit_feature_profile(
                feature_profile_name,
                composition_profile_name=str(
                    self.fixed_hp.get(
                        "pitting_composition_profile",
                        EPIT_COMPOSITION_PROFILE,
                    )
                ),
            )
            process_count = int(feature_profile.metadata["evaluator_preprocessing"]["category_count"])
        elif process_count is None:
            process_values = X[:, process_slice.start].detach()
            process_count = int(torch.nan_to_num(process_values, nan=0.0).long().clamp(min=0).max().item()) + 1
        process_count = int(process_count)
        if process_count < 2:
            raise ValueError("Fixed EPIT process category count must be >= 2.")
        process_offsets = torch.randn(process_count, device=X.device, dtype=X.dtype)

        physical_profile_applied = bool(profile_info is not None and profile_info.physical_profile_applied)
        material_coef = float(self.fixed_hp.get("epit_material_coef", 0.575))
        environment_coef = float(self.fixed_hp.get("epit_environment_coef", 0.50))
        interaction_coef = float(self.fixed_hp.get("epit_interaction_coef", 0.775))
        coefficients = np.asarray([material_coef, environment_coef, interaction_coef], dtype=float)
        if not np.all(np.isfinite(coefficients)) or np.any(coefficients < 0.0):
            raise ValueError("Epit coefficients must be finite and non-negative.")

        rule = {
            "rule_type": "fixed_epit_target_rule_v2_pren_anchor",
            "material_anchor_type": "pren_like_cr_mo_w_weak_ni_v1",
            "environment_rule_type": "chloride_dominant_weak_temp_ph_v1",
            "material_cols": list(range(material_slice.start, material_slice.stop)),
            "temperature_col": int(env_slice.start),
            "chloride_col": int(env_slice.start + 1),
            "ph_col": int(env_slice.start + 2),
            "process_col": int(process_slice.start),
            "material_anchor_weights": material_anchor_weights,
            "material_weights": material_weights.detach().cpu().numpy().astype(float),
            "environment_weights": environment_weights,
            "ph_neutral": float(np.random.uniform(6.3, 8.2)),
            "process_offsets": process_offsets.detach().cpu().numpy().astype(float),
            "process_category_count": process_count,
            "material_coef": material_coef,
            "environment_coef": environment_coef,
            "interaction_coef": interaction_coef,
            "exposure_coef": float(np.random.uniform(0.12, 0.28)),
            "process_coef": float(np.random.uniform(0.03, 0.10)),
            "history_coef": float(np.random.uniform(0.08, 0.20)),
            "descriptor_coef": float(np.random.uniform(0.03, 0.10)),
            "target_mix_weight": float(target_mix_weight),
            "synthetic_environment_mode": "raw" if physical_profile_applied else "rank_semantic",
        }
        if profile_info is not None and profile_info.material_family_ids is not None:
            material_family_ids = profile_info.material_family_ids.detach().cpu()
            if material_family_ids.numel() != X.shape[0]:
                raise ValueError(
                    "Synthetic material-family metadata must match the row count."
                )
            rule.update(
                {
                    "synthetic_material_family_ids": material_family_ids.numpy(),
                    "synthetic_material_family_names": EPIT_FE_NI_FAMILY_NAMES,
                }
            )
        selection = self._sample_fixed_epit_target_rule_family()
        if selection is None:
            return rule
        if material_width < 5:
            raise ValueError(
                "Weighted EPIT target rules require Fe, Cr, Ni, Mo, and W columns."
            )
        family, scores, probabilities = selection
        coefficient_overrides = (
            self._fixed_epit_target_rule_coefficient_overrides()
        )
        coefficients = dict(
            coefficient_overrides.get(
                family,
                EPIT_TARGET_RULE_COEFFICIENTS[family],
            )
        )
        if self.coefficient_variation:
            if family not in coefficient_overrides:
                raise ValueError(f"Missing calibrated coefficients for sampled family {family!r}.")
            worker = get_worker_info()
            if worker is not None and self._coefficient_worker_seed != worker.seed:
                self._coefficient_rng = np.random.default_rng(np.random.SeedSequence([
                    self.fixed_hp.get("pitting_coefficient_variation_seed", 42), worker.seed,
                ]))
                self._coefficient_worker_seed = worker.seed
            draw = sample_coefficients(
                coefficients, self.coefficient_variation, self._coefficient_rng,
                upper_bounds=self.fixed_hp["pitting_coefficient_upper_bounds"][family],
            )
            rule["coefficient_variation"] = {
                "strength": self.coefficient_variation,
                "reference": coefficients,
                "attempts": draw.attempts,
                "rejected_draws": draw.rejected_draws,
                "used_fallback": draw.used_fallback,
            }
            coefficients = draw.coefficients
        coefficient_values = np.asarray(list(coefficients.values()), dtype=float)
        if not np.isclose(coefficient_values.sum(), 1.0):
            raise ValueError(f"Calibrated coefficients for {family!r} must sum to one.")
        rule.update(
            {
                "rule_type": "fixed_epit_target_rule_v3_weighted_family",
                "target_rule_family": family,
                "target_rule_scores": scores,
                "target_rule_probabilities": probabilities,
                "target_rule_score": float(scores[family]),
                "target_rule_probability": float(probabilities[family]),
                "target_rule_coefficients": coefficients,
                "coefficient_source": "all-development Fe/Ni calibration",
                "environment_weights": np.asarray([0.075, 0.925, 0.115]),
                "ph_neutral": 7.25,
                "process_coef": float(
                    coefficients.get("test_method_correction", 0.0)
                ),
            }
        )
        return rule

    def _fixed_epit_environment_values_tensor(
        self, X: Tensor, rule: Dict[str, Any], environment_mode: str
    ) -> Tuple[Tensor, Tensor, Tensor]:
        temperature_col = int(rule["temperature_col"])
        chloride_col = int(rule["chloride_col"])
        ph_col = int(rule["ph_col"])
        neutral = float(rule["ph_neutral"])
        if environment_mode == "rank_semantic":
            temp_u = self._rank_uniform(X[:, temperature_col]).clamp(1e-6, 1.0 - 1e-6)
            chloride_u = self._rank_uniform(X[:, chloride_col]).clamp(1e-6, 1.0 - 1e-6)
            ph_u = self._rank_uniform(X[:, ph_col]).clamp(1e-6, 1.0 - 1e-6)
            temperature_values = -10.0 + 130.0 * temp_u
            chloride_values = self._log_uniform_from_rank(chloride_u, 1e-4, 1e3)
            ph_values = self._piecewise_ph_from_rank(ph_u)
        else:
            temperature_values = torch.nan_to_num(X[:, temperature_col], nan=0.0, posinf=0.0, neginf=0.0)
            chloride_values = torch.nan_to_num(X[:, chloride_col], nan=0.0, posinf=0.0, neginf=0.0)
            ph_values = torch.nan_to_num(X[:, ph_col], nan=neutral, posinf=neutral, neginf=neutral)
        return temperature_values, chloride_values, ph_values

    def _fixed_epit_environment_terms_tensor(
        self, X: Tensor, rule: Dict[str, Any], environment_mode: str
    ) -> Tuple[Tensor, Tensor]:
        temperature_values, chloride_values, ph_values = (
            self._fixed_epit_environment_values_tensor(X, rule, environment_mode)
        )
        neutral = float(rule["ph_neutral"])

        temperature_term = self._standardize_signal(temperature_values)
        chloride_term = self._standardize_signal(torch.log10(chloride_values.clamp_min(1e-12)))
        ph_term = self._standardize_signal(torch.abs(ph_values - neutral))
        weights = torch.as_tensor(rule["environment_weights"], device=X.device, dtype=X.dtype)
        environment_signal = self._standardize_signal(
            weights[0] * temperature_term + weights[1] * chloride_term + weights[2] * ph_term
        )
        return environment_signal, chloride_term

    def _fixed_epit_environment_signal_tensor(self, X: Tensor, rule: Dict[str, Any], environment_mode: str) -> Tensor:
        environment_signal, _ = self._fixed_epit_environment_terms_tensor(X, rule, environment_mode)
        return environment_signal

    def _evaluate_weighted_fixed_epit_target_rule_tensor(
        self,
        X: Tensor,
        rule: Dict[str, Any],
        environment_mode: str,
    ) -> Tuple[Tensor, Tensor]:
        family = str(rule["target_rule_family"])
        coefficients = {
            str(name): float(value)
            for name, value in rule["target_rule_coefficients"].items()
        }
        material_cols = [int(col) for col in rule["material_cols"]]
        if len(material_cols) < 5:
            raise ValueError("Weighted EPIT rules require Fe, Cr, Ni, Mo, and W.")
        material = torch.nan_to_num(
            X[:, material_cols], nan=0.0, posinf=0.0, neginf=0.0
        )
        iron = material[:, 0].clamp_min(0.0)
        chromium = material[:, 1].clamp_min(0.0)
        nickel = material[:, 2].clamp_min(0.0)
        molybdenum = material[:, 3].clamp_min(0.0)
        tungsten = material[:, 4].clamp_min(0.0)
        mow = molybdenum + 0.55 * tungsten
        linear_material = chromium + 3.25 * mow
        synergy_material = linear_material + torch.sqrt(chromium * mow)
        threshold_material = torch.sigmoid((chromium - 12.0) / 2.0) + torch.log1p(mow)
        synthetic_family_ids = rule.get("synthetic_material_family_ids")
        if synthetic_family_ids is None:
            ni_cr_mo_rows = nickel > iron
        else:
            family_ids = torch.as_tensor(
                synthetic_family_ids, device=X.device, dtype=torch.long
            ).reshape(-1)
            if family_ids.shape[0] != X.shape[0] or torch.any(
                (family_ids != EPIT_FE_FAMILY_ID)
                & (family_ids != EPIT_NI_CR_MO_FAMILY_ID)
            ):
                raise ValueError("Invalid synthetic Fe/NiCrMo family metadata.")
            ni_cr_mo_rows = family_ids == EPIT_NI_CR_MO_FAMILY_ID
        class_threshold = torch.where(
            ni_cr_mo_rows,
            torch.full_like(chromium, 15.0),
            torch.full_like(chromium, 12.0),
        )
        fe_ni_threshold_material = (
            torch.sigmoid((chromium - class_threshold) / 2.0) + torch.log1p(mow)
        )

        temperature, chloride, ph = self._fixed_epit_environment_values_tensor(
            X, rule, environment_mode
        )
        temperature_z = self._standardize_signal(temperature)
        chloride_z = self._standardize_signal(
            torch.log10(chloride.clamp_min(1e-12))
        )
        ph_distance_z = self._standardize_signal(torch.abs(ph - 7.25))
        environment = torch.sigmoid(
            self._standardize_signal(
                0.075 * temperature_z
                + 0.925 * chloride_z
                + 0.115 * ph_distance_z
            )
        )
        chloride_drive = torch.sigmoid(chloride_z)
        high_temperature = torch.sigmoid((temperature - 50.0) / 10.0)
        acidic_ph = torch.sigmoid((6.5 - ph) / 1.0)
        temperature_chloride = high_temperature * chloride_drive

        def standardized(values: Tensor) -> Tensor:
            return self._standardize_signal(values)

        if family in {"pren_linear", "improved_environment", "coupled_breakdown"}:
            material_score = linear_material
        elif family in {"cr_mow_synergy", "method_aware"}:
            material_score = synergy_material
        elif family == "threshold_saturation":
            material_score = threshold_material
        elif family == "fe_ni_cr_threshold":
            material_score = fe_ni_threshold_material
        else:
            raise ValueError(f"Unsupported weighted EPIT target rule {family!r}.")

        material_z = standardized(material_score)
        material_passivity = torch.tanh(material_z)
        material_term = standardized(material_passivity)
        material_chloride = torch.sigmoid(-material_z) * chloride_drive
        classic_temperature_chloride = (
            torch.sigmoid(temperature_z) * chloride_drive
        )
        epit_drive = coefficients["material_passivity"] * material_term

        if family in {
            "pren_linear",
            "cr_mow_synergy",
            "threshold_saturation",
            "method_aware",
        }:
            epit_drive = epit_drive - coefficients["environment_aggressiveness"] * standardized(environment)
            epit_drive = epit_drive - coefficients["material_chloride_interaction"] * standardized(
                material_chloride
            )
            if "temperature_chloride_interaction" in coefficients:
                epit_drive = epit_drive - coefficients["temperature_chloride_interaction"] * standardized(
                    classic_temperature_chloride
                )
        elif family in {"improved_environment", "fe_ni_cr_threshold"}:
            epit_drive = epit_drive - coefficients["log_chloride_aggressiveness"] * standardized(
                chloride_drive
            )
            epit_drive = epit_drive - coefficients["high_temperature_aggressiveness"] * standardized(
                high_temperature
            )
            epit_drive = epit_drive - coefficients["temperature_chloride_interaction"] * standardized(
                temperature_chloride
            )
            epit_drive = epit_drive - coefficients["acidic_ph_aggressiveness"] * standardized(
                acidic_ph
            )
        else:
            aggressiveness = (
                0.65 * chloride_z
                + 0.25 * standardized(high_temperature)
                + 0.10 * standardized(temperature_chloride)
            )
            breakdown = torch.sigmoid(aggressiveness - 0.75 * material_z)
            epit_drive = epit_drive - coefficients["coupled_environment_breakdown"] * standardized(
                breakdown
            )
            epit_drive = epit_drive - coefficients["acidic_ph_aggressiveness"] * standardized(
                acidic_ph
            )

        if family == "method_aware":
            process_col = int(rule["process_col"])
            offsets = torch.as_tensor(
                rule["process_offsets"], device=X.device, dtype=X.dtype
            )
            labels = torch.nan_to_num(
                X[:, process_col], nan=0.0, posinf=0.0, neginf=0.0
            ).round().long()
            labels = labels.clamp(min=0, max=max(0, offsets.numel() - 1))
            method_offset = torch.tanh(standardized(offsets[labels]))
            epit_drive = epit_drive + coefficients["test_method_correction"] * standardized(
                method_offset
            )

        if torch.std(epit_drive.float(), unbiased=False) > 1e-6:
            mix_weight = float(rule.get("target_mix_weight", 0.0))
            target_component = mix_weight * standardized(epit_drive)
        else:
            target_component = torch.zeros_like(epit_drive)
        return target_component, epit_drive

    def _evaluate_fixed_epit_target_rule_tensor(
        self, X: Tensor, rule: Dict[str, Any], *, environment_mode: Optional[str] = None
    ) -> Tuple[Tensor, Tensor]:
        mode = str(environment_mode or rule.get("synthetic_environment_mode", "raw"))
        if rule.get("rule_type") == "fixed_epit_target_rule_v3_weighted_family":
            return self._evaluate_weighted_fixed_epit_target_rule_tensor(
                X, rule, mode
            )
        material_cols = [int(col) for col in rule["material_cols"]]
        material = X[:, material_cols]
        material_weights = torch.as_tensor(rule["material_weights"], device=X.device, dtype=X.dtype)
        material_signal = self._standardize_signal(material @ material_weights)
        material_passivity = torch.tanh(material_signal)
        material_susceptibility = torch.sigmoid(-material_signal)

        environment_signal, chloride_signal = self._fixed_epit_environment_terms_tensor(X, rule, mode)
        environment_drive = torch.sigmoid(environment_signal)
        chloride_drive = torch.sigmoid(chloride_signal)

        process_col = int(rule["process_col"])
        offsets = torch.as_tensor(rule["process_offsets"], device=X.device, dtype=X.dtype)
        labels = torch.nan_to_num(X[:, process_col], nan=0.0, posinf=0.0, neginf=0.0).round().long()
        labels = labels.clamp(min=0, max=max(0, offsets.numel() - 1))
        process_signal = self._standardize_signal(offsets[labels])
        process_offset = torch.tanh(process_signal)

        epit_drive = torch.zeros(X.shape[0], device=X.device, dtype=X.dtype)
        epit_drive = epit_drive + float(rule["material_coef"]) * material_passivity
        epit_drive = epit_drive - float(rule["environment_coef"]) * environment_drive
        epit_drive = epit_drive - float(rule["interaction_coef"]) * material_susceptibility * chloride_drive
        epit_drive = epit_drive + float(rule["process_coef"]) * process_offset

        if torch.std(epit_drive.float(), unbiased=False) > 1e-6:
            mix_weight = float(rule.get("target_mix_weight", rule.get("interaction_strength", 0.0)))
            target_component = mix_weight * self._standardize_signal(epit_drive)
        else:
            target_component = torch.zeros_like(epit_drive)
        return target_component, epit_drive

    @classmethod
    def _evaluate_weighted_fixed_epit_target_rule_numpy(
        cls,
        X: np.ndarray,
        rule: Dict[str, Any],
        environment_mode: str,
    ) -> np.ndarray:
        family = str(rule["target_rule_family"])
        coefficients = {
            str(name): float(value)
            for name, value in rule["target_rule_coefficients"].items()
        }
        material_cols = [int(col) for col in rule["material_cols"]]
        if len(material_cols) < 5:
            raise ValueError("Weighted EPIT rules require Fe, Cr, Ni, Mo, and W.")
        material = np.nan_to_num(
            X[:, material_cols], nan=0.0, posinf=0.0, neginf=0.0
        )
        iron = np.clip(material[:, 0], 0.0, None)
        chromium = np.clip(material[:, 1], 0.0, None)
        nickel = np.clip(material[:, 2], 0.0, None)
        molybdenum = np.clip(material[:, 3], 0.0, None)
        tungsten = np.clip(material[:, 4], 0.0, None)
        mow = molybdenum + 0.55 * tungsten
        linear_material = chromium + 3.25 * mow
        synergy_material = linear_material + np.sqrt(chromium * mow)
        threshold_material = 1.0 / (1.0 + np.exp(-(chromium - 12.0) / 2.0)) + np.log1p(mow)
        synthetic_family_ids = rule.get("synthetic_material_family_ids")
        if synthetic_family_ids is None:
            ni_cr_mo_rows = nickel > iron
        else:
            family_ids = np.asarray(synthetic_family_ids, dtype=np.int64).reshape(-1)
            if family_ids.shape[0] != X.shape[0] or np.any(
                (family_ids != EPIT_FE_FAMILY_ID)
                & (family_ids != EPIT_NI_CR_MO_FAMILY_ID)
            ):
                raise ValueError("Invalid synthetic Fe/NiCrMo family metadata.")
            ni_cr_mo_rows = family_ids == EPIT_NI_CR_MO_FAMILY_ID
        class_threshold = np.where(ni_cr_mo_rows, 15.0, 12.0)
        fe_ni_threshold_material = (
            1.0 / (1.0 + np.exp(-(chromium - class_threshold) / 2.0))
            + np.log1p(mow)
        )

        temperature_col = int(rule["temperature_col"])
        chloride_col = int(rule["chloride_col"])
        ph_col = int(rule["ph_col"])
        if environment_mode == "rank_semantic":
            temp_u = np.clip(
                cls._rank_uniform_array(X[:, temperature_col]), 1e-6, 1.0 - 1e-6
            )
            chloride_u = np.clip(
                cls._rank_uniform_array(X[:, chloride_col]), 1e-6, 1.0 - 1e-6
            )
            ph_u = np.clip(
                cls._rank_uniform_array(X[:, ph_col]), 1e-6, 1.0 - 1e-6
            )
            temperature = -10.0 + 130.0 * temp_u
            chloride = cls._log_uniform_from_rank_array(chloride_u, 1e-4, 1e3)
            ph = cls._piecewise_ph_from_rank_array(ph_u)
        else:
            temperature = np.nan_to_num(
                X[:, temperature_col], nan=0.0, posinf=0.0, neginf=0.0
            )
            chloride = np.nan_to_num(
                X[:, chloride_col], nan=0.0, posinf=0.0, neginf=0.0
            )
            ph = np.nan_to_num(
                X[:, ph_col], nan=7.25, posinf=7.25, neginf=7.25
            )

        standardized = cls._standardize_array
        temperature_z = standardized(temperature)
        chloride_z = standardized(np.log10(np.clip(chloride, 1e-12, None)))
        ph_distance_z = standardized(np.abs(ph - 7.25))
        environment_signal = standardized(
            0.075 * temperature_z
            + 0.925 * chloride_z
            + 0.115 * ph_distance_z
        )
        environment = 1.0 / (1.0 + np.exp(-environment_signal))
        chloride_drive = 1.0 / (1.0 + np.exp(-chloride_z))
        high_temperature = 1.0 / (1.0 + np.exp(-(temperature - 50.0) / 10.0))
        acidic_ph = 1.0 / (1.0 + np.exp(-(6.5 - ph)))
        temperature_chloride = high_temperature * chloride_drive

        if family in {"pren_linear", "improved_environment", "coupled_breakdown"}:
            material_score = linear_material
        elif family in {"cr_mow_synergy", "method_aware"}:
            material_score = synergy_material
        elif family == "threshold_saturation":
            material_score = threshold_material
        elif family == "fe_ni_cr_threshold":
            material_score = fe_ni_threshold_material
        else:
            raise ValueError(f"Unsupported weighted EPIT target rule {family!r}.")

        material_z = standardized(material_score)
        material_term = standardized(np.tanh(material_z))
        material_chloride = 1.0 / (1.0 + np.exp(material_z)) * chloride_drive
        classic_temperature_chloride = (
            1.0 / (1.0 + np.exp(-temperature_z)) * chloride_drive
        )
        epit_drive = coefficients["material_passivity"] * material_term

        if family in {
            "pren_linear",
            "cr_mow_synergy",
            "threshold_saturation",
            "method_aware",
        }:
            epit_drive -= coefficients["environment_aggressiveness"] * standardized(environment)
            epit_drive -= coefficients["material_chloride_interaction"] * standardized(
                material_chloride
            )
            if "temperature_chloride_interaction" in coefficients:
                epit_drive -= coefficients["temperature_chloride_interaction"] * standardized(
                    classic_temperature_chloride
                )
        elif family in {"improved_environment", "fe_ni_cr_threshold"}:
            epit_drive -= coefficients["log_chloride_aggressiveness"] * standardized(
                chloride_drive
            )
            epit_drive -= coefficients["high_temperature_aggressiveness"] * standardized(
                high_temperature
            )
            epit_drive -= coefficients["temperature_chloride_interaction"] * standardized(
                temperature_chloride
            )
            epit_drive -= coefficients["acidic_ph_aggressiveness"] * standardized(
                acidic_ph
            )
        else:
            aggressiveness = (
                0.65 * chloride_z
                + 0.25 * standardized(high_temperature)
                + 0.10 * standardized(temperature_chloride)
            )
            breakdown = 1.0 / (1.0 + np.exp(-(aggressiveness - 0.75 * material_z)))
            epit_drive -= coefficients["coupled_environment_breakdown"] * standardized(
                breakdown
            )
            epit_drive -= coefficients["acidic_ph_aggressiveness"] * standardized(
                acidic_ph
            )

        if family == "method_aware":
            offsets = np.asarray(rule["process_offsets"], dtype=float).reshape(-1)
            labels = np.rint(
                np.nan_to_num(
                    X[:, int(rule["process_col"])],
                    nan=0.0,
                    posinf=0.0,
                    neginf=0.0,
                )
            ).astype(int)
            labels = np.clip(labels, 0, max(0, offsets.size - 1))
            method_offset = np.tanh(standardized(offsets[labels]))
            epit_drive += coefficients["test_method_correction"] * standardized(
                method_offset
            )

        mix_weight = float(rule.get("target_mix_weight", 0.0))
        return mix_weight * standardized(epit_drive)

    @classmethod
    def evaluate_fixed_epit_target_rule_numpy(
        cls, X: np.ndarray, rule: Dict[str, Any], *, environment_mode: str = "raw"
    ) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        if X.ndim != 2:
            raise ValueError(f"Expected a 2D feature table, got shape {X.shape}.")
        if rule.get("rule_type") == "fixed_epit_target_rule_v3_weighted_family":
            return cls._evaluate_weighted_fixed_epit_target_rule_numpy(
                X, rule, environment_mode
            )
        material_cols = [int(col) for col in rule["material_cols"]]
        material_weights = np.asarray(rule["material_weights"], dtype=float).reshape(-1)
        material_signal = cls._standardize_array(X[:, material_cols] @ material_weights)
        material_passivity = np.tanh(material_signal)
        material_susceptibility = 1.0 / (1.0 + np.exp(material_signal))

        temperature_col = int(rule["temperature_col"])
        chloride_col = int(rule["chloride_col"])
        ph_col = int(rule["ph_col"])
        neutral = float(rule["ph_neutral"])
        if environment_mode == "rank_semantic":
            temp_u = np.clip(cls._rank_uniform_array(X[:, temperature_col]), 1e-6, 1.0 - 1e-6)
            chloride_u = np.clip(cls._rank_uniform_array(X[:, chloride_col]), 1e-6, 1.0 - 1e-6)
            ph_u = np.clip(cls._rank_uniform_array(X[:, ph_col]), 1e-6, 1.0 - 1e-6)
            temperature_values = -10.0 + 130.0 * temp_u
            chloride_values = cls._log_uniform_from_rank_array(chloride_u, 1e-4, 1e3)
            ph_values = cls._piecewise_ph_from_rank_array(ph_u)
        else:
            temperature_values = np.nan_to_num(X[:, temperature_col], nan=0.0, posinf=0.0, neginf=0.0)
            chloride_values = np.nan_to_num(X[:, chloride_col], nan=0.0, posinf=0.0, neginf=0.0)
            ph_values = np.nan_to_num(X[:, ph_col], nan=neutral, posinf=neutral, neginf=neutral)

        temperature_term = cls._standardize_array(temperature_values)
        chloride_term = cls._standardize_array(np.log10(np.clip(chloride_values, 1e-12, None)))
        ph_term = cls._standardize_array(np.abs(ph_values - neutral))
        env_weights = np.asarray(rule["environment_weights"], dtype=float).reshape(-1)
        environment_signal = cls._standardize_array(
            env_weights[0] * temperature_term + env_weights[1] * chloride_term + env_weights[2] * ph_term
        )
        environment_drive = 1.0 / (1.0 + np.exp(-environment_signal))
        chloride_drive = 1.0 / (1.0 + np.exp(-chloride_term))

        process_col = int(rule["process_col"])
        offsets = np.asarray(rule["process_offsets"], dtype=float).reshape(-1)
        labels = np.rint(np.nan_to_num(X[:, process_col], nan=0.0, posinf=0.0, neginf=0.0)).astype(int)
        labels = np.clip(labels, 0, max(0, offsets.size - 1))
        process_signal = cls._standardize_array(offsets[labels])
        process_offset = np.tanh(process_signal)

        epit_drive = np.zeros(X.shape[0], dtype=float)
        epit_drive += float(rule["material_coef"]) * material_passivity
        epit_drive -= float(rule["environment_coef"]) * environment_drive
        epit_drive -= float(rule["interaction_coef"]) * material_susceptibility * chloride_drive
        epit_drive += float(rule["process_coef"]) * process_offset
        standardized_drive = cls._standardize_array(epit_drive)
        mix_weight = float(rule.get("target_mix_weight", rule.get("interaction_strength", 0.0)))
        return mix_weight * standardized_drive

    def _pitting_profile_block_signal(
        self,
        X: Tensor,
        cols: list[int],
        categorical_cols: Optional[set[int]] = None,
        log_positive: bool = False,
    ) -> Optional[Tensor]:
        if not cols:
            return None
        categorical_cols = categorical_cols or set()
        signals = []
        for col in cols:
            values = torch.nan_to_num(X[:, col], nan=0.0, posinf=0.0, neginf=0.0)
            if col in categorical_cols:
                labels = values.long().clamp(min=0)
                n_categories = int(labels.max().item()) + 1 if labels.numel() else 1
                offsets = torch.randn(max(n_categories, 1), device=X.device, dtype=X.dtype)
                signals.append(offsets[labels.clamp(max=offsets.numel() - 1)])
            elif log_positive:
                signals.append(torch.log1p(values.clamp_min(0.0)))
            else:
                signals.append(values)
        block = torch.stack(signals, dim=-1)
        if block.shape[-1] == 1:
            return self._standardize_signal(block[:, 0])
        weights = torch.randn(block.shape[-1], device=X.device, dtype=X.dtype)
        weights = weights / torch.linalg.vector_norm(weights).clamp_min(1e-6)
        return self._standardize_signal(block @ weights)

    def _pitting_material_dirichlet_prob(self) -> float:
        prob = float(self.fixed_hp.get("pitting_material_dirichlet_prob", 0.0))
        if not np.isfinite(prob):
            raise ValueError("pitting_material_dirichlet_prob must be finite.")
        return float(np.clip(prob, 0.0, 1.0))

    def _pitting_material_dirichlet_concentration(self) -> float:
        concentration = float(self.fixed_hp.get("pitting_material_dirichlet_concentration", 1.0))
        if not np.isfinite(concentration) or concentration <= 0.0:
            raise ValueError("pitting_material_dirichlet_concentration must be finite and positive.")
        return float(np.clip(concentration, 1e-3, 100.0))

    def _pitting_material_dirichlet_active_prob(self, width: int) -> float:
        active_prob = float(self.fixed_hp.get("pitting_material_dirichlet_active_prob", 0.45))
        if not np.isfinite(active_prob):
            raise ValueError("pitting_material_dirichlet_active_prob must be finite.")
        return float(np.clip(active_prob, 0.0, 1.0))

    def _validate_fe_ni_softmax_configuration(self) -> None:
        if not self._fixed_epit_schema_enabled():
            raise ValueError("fe_ni_softmax requires pitting_fixed_epit_schema=True.")
        if float(self.fixed_hp.get("informed_physical_marginal_prob", 0.0)) != 1.0:
            raise ValueError("fe_ni_softmax requires informed_physical_marginal_prob=1.")
        style_probs = np.asarray(
            self.fixed_hp.get("pitting_material_style_probs"), dtype=float
        )
        if style_probs.shape != (5,) or not np.allclose(
            style_probs, (1.0, 0.0, 0.0, 0.0, 0.0)
        ):
            raise ValueError(
                "fe_ni_softmax requires composition-like material style only."
            )
        if self._pitting_material_dirichlet_prob() != 0.0:
            raise ValueError("fe_ni_softmax does not permit masked Dirichlet sampling.")

    @staticmethod
    def _rearrange_fe_ni_softmax_composition(
        composition: Tensor, family_ids: Tensor
    ) -> Tensor:
        """Move row order statistics to family-defining element positions.

        The operation constructs a complete row-wise permutation. It changes
        elemental identities without changing any generated percentage.
        """

        if composition.ndim != 2 or composition.shape[1] < 4:
            raise ValueError("Fe/NiCrMo rearrangement requires a 2D material table.")
        family_ids = torch.as_tensor(
            family_ids, device=composition.device, dtype=torch.long
        ).reshape(-1)
        if family_ids.shape[0] != composition.shape[0]:
            raise ValueError("One Fe/NiCrMo family id is required per composition row.")
        if torch.any(
            (family_ids != EPIT_FE_FAMILY_ID)
            & (family_ids != EPIT_NI_CR_MO_FAMILY_ID)
        ):
            raise ValueError("Fe/NiCrMo family ids must be 0 (Fe) or 1 (NiCrMo).")

        sorted_sources = torch.argsort(composition, dim=-1, descending=True)
        permutation = torch.arange(
            composition.shape[1], device=composition.device, dtype=torch.long
        ).expand(composition.shape[0], -1).clone()

        def place_source(rows: Tensor, destination: int, rank: int) -> None:
            if rows.numel() == 0:
                return
            sources = sorted_sources[rows, rank]
            current_positions = torch.argmax(
                (permutation[rows] == sources.unsqueeze(-1)).to(torch.int64),
                dim=-1,
            )
            displaced_sources = permutation[rows, destination].clone()
            permutation[rows, destination] = sources
            permutation[rows, current_positions] = displaced_sources

        fe_rows = torch.nonzero(
            family_ids == EPIT_FE_FAMILY_ID, as_tuple=False
        ).flatten()
        ni_rows = torch.nonzero(
            family_ids == EPIT_NI_CR_MO_FAMILY_ID, as_tuple=False
        ).flatten()
        place_source(fe_rows, destination=0, rank=0)  # Fe receives the largest value.
        place_source(ni_rows, destination=2, rank=0)  # Ni receives the largest value.
        place_source(ni_rows, destination=1, rank=1)  # Cr receives the second largest.
        place_source(ni_rows, destination=3, rank=2)  # Mo receives the third largest.
        return torch.gather(composition, dim=1, index=permutation)

    def _apply_fe_ni_softmax_composition(
        self, composition: Tensor, info: PittingProfileInfo
    ) -> Tensor:
        if composition.shape[1] != EPIT_MATERIAL_FEATURE_COUNT:
            raise ValueError(
                "fe_ni_softmax requires the fixed 24-column EPIT material schema."
            )
        sampled_ids = np.random.choice(
            len(EPIT_FE_NI_FAMILY_NAMES),
            size=composition.shape[0],
            p=np.asarray(EPIT_FE_NI_FAMILY_PROBS, dtype=float),
        )
        family_ids = torch.as_tensor(
            sampled_ids, device=composition.device, dtype=torch.long
        )
        rearranged = self._rearrange_fe_ni_softmax_composition(
            composition, family_ids
        )
        info.material_family_ids = family_ids
        self.last_pitting_material_family_ids = family_ids.detach().cpu()
        return rearranged

    def _apply_masked_dirichlet_composition_marginal(self, X: Tensor, feature_slice: slice) -> None:
        width = feature_slice.stop - feature_slice.start
        if width <= 1:
            return

        n_rows = X.shape[0]
        device = X.device
        sample_dtype = torch.float32 if X.dtype in (torch.float16, torch.bfloat16) else X.dtype
        concentration = self._pitting_material_dirichlet_concentration()
        active_prob = self._pitting_material_dirichlet_active_prob(width)

        mask = torch.rand(n_rows, width, device=device) < active_prob
        min_active = min(width, 2)
        active_counts = mask.sum(dim=-1)
        needs_forced = active_counts < min_active
        if torch.any(needs_forced):
            forced_scores = torch.rand(n_rows, width, device=device)
            forced_idx = torch.topk(forced_scores, k=min_active, dim=-1).indices
            forced_mask = torch.zeros_like(mask)
            forced_mask.scatter_(1, forced_idx, True)
            mask = torch.where(needs_forced.unsqueeze(-1), mask | forced_mask, mask)

        alpha = torch.full((n_rows, width), concentration, device=device, dtype=sample_dtype)
        gamma = torch.distributions.Gamma(alpha, torch.ones_like(alpha)).sample()
        gamma = gamma * mask.to(dtype=sample_dtype)
        row_sum = gamma.sum(dim=-1, keepdim=True)
        empty_rows = row_sum <= 1e-20
        if torch.any(empty_rows):
            gamma = torch.where(empty_rows, mask.to(dtype=sample_dtype), gamma)
            row_sum = gamma.sum(dim=-1, keepdim=True)

        composition = gamma / row_sum.clamp_min(1e-12) * 100.0
        X[:, feature_slice] = composition.to(dtype=X.dtype)

    def _apply_pitting_material_profile(self, X: Tensor, blocks: Dict[str, slice], info: PittingProfileInfo) -> None:
        material_slice = blocks.get("material")
        if material_slice is None or material_slice.stop <= material_slice.start:
            return

        start, stop = material_slice.start, material_slice.stop
        width = stop - start
        if width <= 0:
            return

        if self._empirical_pitting_composition_enabled():
            profile_name = str(self.fixed_hp.get("pitting_composition_profile", EPIT_COMPOSITION_PROFILE))
            profile = load_epit_composition_profile(profile_name)
            if width != len(profile.observed_elements):
                raise ValueError(
                    "Empirical EPIT composition requires one output column per observed element "
                    f"({len(profile.observed_elements)}), got {width}."
                )
            cols = list(range(start, stop))
            info.material_style = "empirical_template_composition"
            for col in cols:
                info.add_role("material_empirical_composition", col)
            passivity = self._pitting_profile_block_signal(X, cols, log_positive=True)
            if passivity is None:
                return
            susceptibility_noise = self._pitting_profile_block_signal(X, cols, log_positive=True)
            if susceptibility_noise is None:
                susceptibility_noise = -passivity
            info.material_passivity = passivity
            info.material_susceptibility = self._standardize_signal(
                -0.75 * passivity + 0.25 * susceptibility_noise
            )
            return

        styles = [
            "composition_like",
            "sparse_alloying",
            "bounded_partial_composition",
            "descriptor_like",
            "mixed_metadata",
        ]
        configured_probs = self.fixed_hp.get("pitting_material_style_probs")
        probs = np.asarray(
            [0.30, 0.22, 0.20, 0.18, 0.10] if configured_probs is None else configured_probs,
            dtype=float,
        ).reshape(-1)
        if probs.size != len(styles):
            raise ValueError(
                "pitting_material_style_probs must contain five values in this order: "
                "composition-like, sparse-alloying, partial-composition, descriptor-like, mixed-metadata."
            )
        if not np.all(np.isfinite(probs)) or np.any(probs < 0.0):
            raise ValueError("pitting_material_style_probs must be finite and non-negative.")
        if width == 1:
            styles = ["bounded_partial_composition", "descriptor_like"]
            probs = probs[[2, 3]]
        if float(probs.sum()) <= 0.0:
            raise ValueError("pitting_material_style_probs must enable at least one available material style.")
        probs = probs / probs.sum()
        style = str(np.random.choice(styles, p=probs))
        info.material_style = style

        cols = list(range(start, stop))
        categorical_cols: set[int] = set()

        if style == "composition_like":
            if np.random.random() < self._pitting_material_dirichlet_prob():
                self._apply_masked_dirichlet_composition_marginal(X, material_slice)
                info.material_style = "masked_dirichlet_composition"
                role = "material_dirichlet_composition"
            else:
                logits = torch.nan_to_num(X[:, material_slice], nan=0.0, posinf=0.0, neginf=0.0)
                shared = self._standardize_signal(logits.mean(dim=-1)).unsqueeze(-1)
                latent_weights = torch.randn(1, width, device=X.device, dtype=X.dtype)
                sharpness = float(np.random.uniform(0.7, 1.8))
                logits = 0.55 * logits + 0.45 * shared * latent_weights
                composition = torch.softmax(logits * sharpness, dim=-1) * 100.0
                if np.random.random() < 0.30:
                    row_scale = torch.empty(X.shape[0], 1, device=X.device, dtype=X.dtype).uniform_(0.92, 1.08)
                    composition = composition * row_scale
                if self._fe_ni_softmax_pitting_composition_enabled():
                    composition = self._apply_fe_ni_softmax_composition(
                        composition, info
                    )
                    info.material_style = "fe_ni_softmax_composition"
                    role = "material_fe_ni_softmax_composition"
                else:
                    role = "material_composition"
                X[:, material_slice] = composition
            for col in cols:
                info.add_role(role, col)
            signal_cols = cols
            log_positive = True
        elif style == "sparse_alloying":
            for col in cols:
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                active_prob = float(np.random.uniform(0.06, 0.35))
                active = self._rank_uniform(X[:, col] + 0.05 * torch.randn_like(X[:, col])) > (1.0 - active_prob)
                values = self._log_uniform_from_rank(u, 1e-3, float(np.random.uniform(1.0, 18.0)))
                if np.random.random() < 0.35:
                    values = values * float(np.random.uniform(0.02, 0.25))
                X[:, col] = torch.where(active, values, torch.zeros_like(values))
                info.add_role("material_sparse_alloying", col)
            signal_cols = cols
            log_positive = True
        elif style == "bounded_partial_composition":
            for col in cols:
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                upper = float(np.random.uniform(5.0, 100.0))
                exponent = float(np.random.uniform(0.55, 2.2))
                X[:, col] = upper * torch.pow(u, exponent)
                info.add_role("material_partial_composition", col)
            signal_cols = cols
            log_positive = True
        elif style == "descriptor_like":
            families = ["descriptor_standard", "descriptor_positive", "descriptor_bounded", "material_property"]
            for col in cols:
                family = str(np.random.choice(families, p=[0.45, 0.20, 0.25, 0.10]))
                X[:, col] = self._corrosion_marginal_values(X[:, col], family)
                info.add_role("material_descriptor", col)
            signal_cols = cols
            log_positive = False
        else:
            n_cat = 0 if width <= 2 else int(np.random.choice([0, 1, 1, min(2, width // 4)]))
            cat_positions = set(np.random.choice(cols, size=n_cat, replace=False).tolist()) if n_cat > 0 else set()
            for col in cols:
                if col in cat_positions:
                    n_categories = int(np.random.choice([2, 3, 4, 5]))
                    X[:, col] = self._categorical_values_from_rank(X[:, col], n_categories)
                    info.add_role("material_category", col, categorical=True)
                    categorical_cols.add(col)
                else:
                    family = str(np.random.choice(["descriptor_standard", "descriptor_bounded", "material_bounded"]))
                    X[:, col] = self._corrosion_marginal_values(X[:, col], family)
                    info.add_role("material_descriptor", col)
            signal_cols = [col for col in cols if col not in categorical_cols] or cols
            log_positive = False

        passivity = self._pitting_profile_block_signal(X, signal_cols, categorical_cols, log_positive=log_positive)
        if passivity is None:
            return
        susceptibility_noise = self._pitting_profile_block_signal(X, signal_cols, categorical_cols, log_positive=log_positive)
        if susceptibility_noise is None:
            susceptibility_noise = -passivity
        info.material_passivity = passivity
        info.material_susceptibility = self._standardize_signal(-0.75 * passivity + 0.25 * susceptibility_noise)

    def _sample_pitting_environment_roles(self, width: int) -> list[str]:
        if self._fixed_epit_schema_enabled() and width >= 3:
            return ["temperature_like", "chloride_like", "ph_like"] + ["environment_proxy"] * (width - 3)
        candidates = [
            ("chloride_like", 0.78),
            ("ph_like", 0.55),
            ("temperature_like", 0.65),
            ("solution_concentration_like", 0.42),
            ("solution_category", 0.32),
        ]
        selected = [role for role, prob in candidates if np.random.random() < prob]
        if not selected:
            selected = [str(np.random.choice([role for role, _ in candidates]))]
        if width >= 2 and "chloride_like" not in selected and np.random.random() < 0.45:
            selected.insert(0, "chloride_like")
        np.random.shuffle(selected)
        fillers = ["environment_proxy", "solution_concentration_like", "temperature_like", "solution_category"]
        while len(selected) < width:
            selected.append(str(np.random.choice(fillers)))
        return selected[:width]

    def _apply_pitting_environment_profile(self, X: Tensor, blocks: Dict[str, slice], info: PittingProfileInfo) -> None:
        env_slice = blocks.get("environment")
        if env_slice is None or env_slice.stop <= env_slice.start:
            return

        roles = self._sample_pitting_environment_roles(env_slice.stop - env_slice.start)
        terms = []
        weights = []
        for col, role in zip(range(env_slice.start, env_slice.stop), roles):
            if role == "chloride_like":
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                X[:, col] = self._log_uniform_from_rank(u, 1e-4, float(np.random.uniform(1.0, 1e3)))
                term = self._standardize_signal(torch.log10(X[:, col].clamp_min(1e-12)))
                info.add_role(role, col)
                weight = float(np.random.uniform(0.35, 0.75))
            elif role == "ph_like":
                X[:, col] = self._piecewise_ph_from_rank(self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6))
                neutral = float(np.random.uniform(6.3, 8.2))
                term = self._standardize_signal(torch.abs(X[:, col] - neutral))
                info.add_role(role, col)
                weight = float(np.random.uniform(0.20, 0.50))
            elif role == "temperature_like":
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                low = float(np.random.uniform(-15.0, 10.0))
                high = float(np.random.uniform(70.0, 160.0))
                X[:, col] = low + (high - low) * u
                term = self._standardize_signal(X[:, col])
                info.add_role(role, col)
                weight = float(np.random.uniform(0.18, 0.45))
            elif role == "solution_category":
                n_categories = int(np.random.choice([2, 3, 4, 5, 6]))
                X[:, col] = self._categorical_values_from_rank(X[:, col], n_categories)
                labels = X[:, col].long().clamp(min=0, max=n_categories - 1)
                offsets = torch.randn(n_categories, device=X.device, dtype=X.dtype)
                term = self._standardize_signal(offsets[labels])
                info.add_role(role, col, categorical=True)
                weight = float(np.random.uniform(0.12, 0.35))
            elif role == "solution_concentration_like":
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                X[:, col] = self._log_uniform_from_rank(u, 1e-5, float(np.random.uniform(0.5, 100.0)))
                term = self._standardize_signal(torch.log10(X[:, col].clamp_min(1e-12)))
                info.add_role(role, col)
                weight = float(np.random.uniform(0.15, 0.40))
            else:
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                X[:, col] = torch.pow(u, float(np.random.uniform(0.55, 2.0)))
                term = self._standardize_signal(X[:, col])
                info.add_role(role, col)
                weight = float(np.random.uniform(0.08, 0.25))
            terms.append(term)
            weights.append(weight)

        if terms:
            stacked = torch.stack(terms, dim=-1)
            weight_tensor = torch.tensor(weights, device=X.device, dtype=X.dtype)
            info.environment_aggressiveness = self._standardize_signal(stacked @ weight_tensor)

    def _apply_pitting_process_profile(self, X: Tensor, blocks: Dict[str, slice], info: PittingProfileInfo) -> None:
        process_slice = blocks.get("process_history")
        if process_slice is None or process_slice.stop <= process_slice.start:
            return

        role_pool = [
            "test_method_category",
            "heat_treatment_category",
            "microstructure_category",
            "surface_process_score",
            "exposure_history_proxy",
        ]
        fixed_role = self.fixed_hp.get("pitting_process_role")
        if fixed_role is not None:
            fixed_role = str(fixed_role).strip().replace("-", "_")
            if fixed_role not in role_pool:
                raise ValueError(
                    "pitting_process_role must be one of: " + ", ".join(role_pool)
                )

        fixed_category_count = self.fixed_hp.get("pitting_process_category_count")
        if fixed_category_count is not None:
            fixed_category_count_float = float(fixed_category_count)
            if (
                not np.isfinite(fixed_category_count_float)
                or fixed_category_count_float < 2
                or not fixed_category_count_float.is_integer()
            ):
                raise ValueError("pitting_process_category_count must be an integer >= 2.")
            fixed_category_count = int(fixed_category_count_float)

        offset_terms = []
        damage_terms = []
        for col in range(process_slice.start, process_slice.stop):
            role = fixed_role or str(np.random.choice(role_pool, p=[0.28, 0.20, 0.18, 0.22, 0.12]))
            if role.endswith("category"):
                n_categories = fixed_category_count or int(np.random.choice([2, 3, 4, 5]))
                X[:, col] = self._categorical_values_from_rank(X[:, col], n_categories)
                labels = X[:, col].long().clamp(min=0, max=n_categories - 1)
                offsets = torch.randn(n_categories, device=X.device, dtype=X.dtype)
                offset_terms.append(self._standardize_signal(offsets[labels]))
                info.add_role(role, col, categorical=True)
            elif role == "exposure_history_proxy":
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                X[:, col] = self._log_uniform_from_rank(u, 1e-2, 1e5)
                damage_terms.append(self._standardize_signal(torch.log10(X[:, col].clamp_min(1e-12))))
                info.add_role(role, col)
            else:
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                X[:, col] = torch.pow(u, float(np.random.uniform(0.5, 2.0)))
                sign = float(np.random.choice([-1.0, 1.0]))
                offset_terms.append(sign * self._standardize_signal(X[:, col]))
                info.add_role(role, col)

        if offset_terms:
            info.process_offset = self._standardize_signal(torch.stack(offset_terms, dim=-1).mean(dim=-1))
        if damage_terms:
            info.exposure_damage = self._standardize_signal(torch.stack(damage_terms, dim=-1).mean(dim=-1))

    def _apply_pitting_descriptor_profile(self, X: Tensor, blocks: Dict[str, slice], info: PittingProfileInfo) -> None:
        descriptor_slice = blocks.get("molecular_descriptor")
        if descriptor_slice is None or descriptor_slice.stop <= descriptor_slice.start:
            return

        cols = list(range(descriptor_slice.start, descriptor_slice.stop))
        for col in cols:
            family = str(np.random.choice(["descriptor_standard", "descriptor_bounded", "descriptor_positive"]))
            X[:, col] = self._corrosion_marginal_values(X[:, col], family)
            info.add_role("pitting_material_descriptor", col)
        info.descriptor_signal = self._pitting_profile_block_signal(X, cols)

    def _apply_pitting_intervention_profile(
        self, X: Tensor, blocks: Dict[str, slice], family: str, info: PittingProfileInfo
    ) -> None:
        if family != "inhibitor_agent":
            return
        intervention_slice = blocks.get("direct_intervention")
        if intervention_slice is None or intervention_slice.stop <= intervention_slice.start:
            return

        terms = []
        for col in range(intervention_slice.start, intervention_slice.stop):
            if np.random.random() < 0.50:
                n_categories = int(np.random.choice([2, 3, 4]))
                X[:, col] = self._categorical_values_from_rank(X[:, col], n_categories)
                labels = X[:, col].long().clamp(min=0, max=n_categories - 1)
                offsets = torch.randn(n_categories, device=X.device, dtype=X.dtype)
                terms.append(self._standardize_signal(offsets[labels]))
                info.add_role("intervention_category", col, categorical=True)
            else:
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                X[:, col] = torch.pow(u, float(np.random.uniform(0.5, 2.0)))
                terms.append(self._standardize_signal(X[:, col]))
                info.add_role("intervention_dose", col)
        if terms:
            info.intervention_signal = self._standardize_signal(torch.stack(terms, dim=-1).mean(dim=-1))

    def _apply_pitting_potential_profile(
        self, X: Tensor, blocks: Dict[str, slice], family: str
    ) -> Tuple[Tensor, PittingProfileInfo]:
        info = PittingProfileInfo()
        if self._fe_ni_softmax_pitting_composition_enabled():
            self._validate_fe_ni_softmax_configuration()
        marginal_prob = float(self.fixed_hp.get("informed_physical_marginal_prob", 0.0))
        marginal_prob = float(np.clip(marginal_prob, 0.0, 1.0))
        apply_full_profile = marginal_prob > 0.0 and np.random.random() < marginal_prob
        info.physical_profile_applied = bool(apply_full_profile)
        force_process_profile = self.fixed_hp.get("pitting_process_role") is not None
        if not apply_full_profile and not force_process_profile:
            return X, info

        X = X.clone()
        info.applied = True
        if apply_full_profile:
            self._apply_pitting_material_profile(X, blocks, info)
            self._apply_pitting_environment_profile(X, blocks, info)
        self._apply_pitting_process_profile(X, blocks, info)
        if apply_full_profile:
            self._apply_pitting_descriptor_profile(X, blocks, info)
            self._apply_pitting_intervention_profile(X, blocks, family, info)
        return torch.nan_to_num(X), info

    def _apply_inhibitor_material_profile(
        self, X: Tensor, blocks: Dict[str, slice], info: InhibitorEfficiencyProfileInfo
    ) -> None:
        material_slice = blocks.get("material")
        if material_slice is None or material_slice.stop <= material_slice.start:
            return

        material_width = material_slice.stop - material_slice.start
        terms = []
        for col in range(material_slice.start, material_slice.stop):
            if material_width == 1 or np.random.random() < 0.70:
                n_categories = 2 if material_width == 1 else int(np.random.choice([2, 2, 3, 4]))
                X[:, col] = self._categorical_values_from_rank(X[:, col], n_categories)
                labels = X[:, col].long().clamp(min=0, max=n_categories - 1)
                offsets = torch.randn(n_categories, device=X.device, dtype=X.dtype)
                terms.append(self._standardize_signal(offsets[labels]))
                info.add_role("alloy_category", col, categorical=True)
            else:
                family = str(np.random.choice(["material_bounded", "material_property", "descriptor_standard"]))
                X[:, col] = self._corrosion_marginal_values(X[:, col], family)
                terms.append(self._standardize_signal(X[:, col]))
                info.add_role("alloy_descriptor", col)

        if terms:
            info.material_modifier = self._standardize_signal(torch.stack(terms, dim=-1).mean(dim=-1))

    def _apply_inhibitor_environment_profile(
        self, X: Tensor, blocks: Dict[str, slice], info: InhibitorEfficiencyProfileInfo
    ) -> None:
        env_slice = blocks.get("environment")
        if env_slice is None or env_slice.stop <= env_slice.start:
            return

        env_width = env_slice.stop - env_slice.start
        terms = []
        for col in range(env_slice.start, env_slice.stop):
            role = "ph_condition" if env_width == 1 else str(
                np.random.choice(["ph_like", "ph_like", "environment_bounded", "solution_category"])
            )
            if role == "ph_like":
                X[:, col] = self._piecewise_ph_from_rank(self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6))
                optimum = float(np.random.uniform(4.0, 10.5))
                terms.append(self._standardize_signal(-torch.abs(X[:, col] - optimum)))
                info.add_role(role, col)
            elif role == "ph_condition":
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                X[:, col] = torch.where(u < 0.5, torch.full_like(X[:, col], 4.0), torch.full_like(X[:, col], 10.0))
                terms.append(self._standardize_signal(torch.where(X[:, col] <= 7.0, 1.0, -1.0)))
                info.add_role(role, col)
            elif role == "solution_category":
                n_categories = int(np.random.choice([2, 3, 4, 5]))
                X[:, col] = self._categorical_values_from_rank(X[:, col], n_categories)
                labels = X[:, col].long().clamp(min=0, max=n_categories - 1)
                offsets = torch.randn(n_categories, device=X.device, dtype=X.dtype)
                terms.append(self._standardize_signal(offsets[labels]))
                info.add_role(role, col, categorical=True)
            else:
                X[:, col] = self._corrosion_marginal_values(X[:, col], "environment_bounded")
                terms.append(self._standardize_signal(X[:, col]))
                info.add_role(role, col)

        if terms:
            info.environment_modifier = self._standardize_signal(torch.stack(terms, dim=-1).mean(dim=-1))

    def _apply_inhibitor_descriptor_profile(
        self, X: Tensor, blocks: Dict[str, slice], info: InhibitorEfficiencyProfileInfo
    ) -> None:
        descriptor_slice = blocks.get("molecular_descriptor")
        if descriptor_slice is None or descriptor_slice.stop <= descriptor_slice.start:
            return

        cols = list(range(descriptor_slice.start, descriptor_slice.stop))
        for col in cols:
            family = str(
                np.random.choice(
                    [
                        "descriptor_standard",
                        "descriptor_standard",
                        "descriptor_bounded",
                        "descriptor_positive",
                        "descriptor_count",
                    ]
                )
            )
            X[:, col] = self._corrosion_marginal_values(X[:, col], family)
            info.add_role("molecular_descriptor", col)
        info.descriptor_efficacy = self._pitting_profile_block_signal(X, cols)

    def _apply_inhibitor_intervention_profile(
        self, X: Tensor, blocks: Dict[str, slice], info: InhibitorEfficiencyProfileInfo
    ) -> None:
        intervention_slice = blocks.get("direct_intervention")
        if intervention_slice is None or intervention_slice.stop <= intervention_slice.start:
            return

        terms = []
        for col in range(intervention_slice.start, intervention_slice.stop):
            if np.random.random() < 0.40:
                n_categories = int(np.random.choice([2, 3, 4]))
                X[:, col] = self._categorical_values_from_rank(X[:, col], n_categories)
                labels = X[:, col].long().clamp(min=0, max=n_categories - 1)
                offsets = torch.randn(n_categories, device=X.device, dtype=X.dtype)
                terms.append(self._standardize_signal(offsets[labels]))
                info.add_role("dose_or_treatment_category", col, categorical=True)
            else:
                u = self._rank_uniform(X[:, col]).clamp(1e-6, 1.0 - 1e-6)
                X[:, col] = torch.pow(u, float(np.random.uniform(0.45, 2.4)))
                terms.append(self._standardize_signal(X[:, col]))
                info.add_role("dose_like", col)

        if terms:
            info.intervention_signal = self._standardize_signal(torch.stack(terms, dim=-1).mean(dim=-1))

    def _apply_inhibitor_efficiency_profile(
        self, X: Tensor, blocks: Dict[str, slice], family: str
    ) -> Tuple[Tensor, InhibitorEfficiencyProfileInfo]:
        info = InhibitorEfficiencyProfileInfo()
        marginal_prob = float(self.fixed_hp.get("informed_physical_marginal_prob", 0.0))
        marginal_prob = float(np.clip(marginal_prob, 0.0, 1.0))
        if marginal_prob <= 0.0 or np.random.random() >= marginal_prob:
            return X, info

        X = X.clone()
        info.applied = True
        self._apply_inhibitor_material_profile(X, blocks, info)
        self._apply_inhibitor_environment_profile(X, blocks, info)
        self._apply_inhibitor_descriptor_profile(X, blocks, info)
        self._apply_inhibitor_intervention_profile(X, blocks, info)
        return torch.nan_to_num(X), info

    def apply_informed_physical_marginals(self, X: Tensor, blocks: Dict[str, slice]) -> Tensor:
        """Apply physical marginal shapes to informed corrosion-like feature blocks."""
        profile = self._informed_physical_marginal_profile()
        if profile in {"false", "none", "off", "disabled"}:
            return X
        if self._is_pitting_profile_name(profile):
            X, _ = self._apply_pitting_potential_profile(X, blocks, "normal_corrosion")
            return X
        if self._is_inhibitor_efficiency_profile_name(profile):
            X, _ = self._apply_inhibitor_efficiency_profile(X, blocks, "inhibitor_agent")
            return X

        marginal_prob = float(self.fixed_hp.get("informed_physical_marginal_prob", 0.0))
        marginal_prob = float(np.clip(marginal_prob, 0.0, 1.0))
        if marginal_prob <= 0.0 or np.random.random() >= marginal_prob:
            return X

        if profile not in {"corrosion_broad", "broad", "corrosion"}:
            raise ValueError(f"Unknown informed physical marginal profile: {profile}")

        X = X.clone()

        material_slice = blocks.get("material")
        if material_slice is not None and material_slice.stop > material_slice.start:
            start = material_slice.start
            if material_slice.stop - material_slice.start >= 2 and np.random.random() < 0.70:
                width = material_slice.stop - material_slice.start
                comp_width = min(width, max(2, int(round(width * np.random.uniform(0.50, 1.00)))))
                self._apply_composition_marginal(X, slice(start, start + comp_width))
                start += comp_width
            for col in range(start, material_slice.stop):
                family = str(
                    np.random.choice(
                        [
                            "material_fraction",
                            "material_fraction",
                            "material_bounded",
                            "material_category",
                            "material_property",
                        ]
                    )
                )
                X[:, col] = self._corrosion_marginal_values(X[:, col], family)

        block_families = {
            "environment": [
                "environment_bounded",
                "environment_bounded",
                "environment_category",
                "ph",
                "temperature",
                "concentration",
                "chloride",
                "salinity",
            ],
            "electrochem_control": ["potential", "current_density", "resistance"],
            "electrochem_downstream": ["potential", "current_density", "resistance"],
            "process_history": [
                "process_category",
                "process_category",
                "process_binary",
                "process_score",
                "exposure_time",
                "cycle_count",
            ],
            "exposure_duration": ["exposure_time", "cycle_count"],
            "temporal_history": ["exposure_time", "cycle_count", "prior_damage"],
            "direct_intervention": [
                "intervention_category",
                "intervention_category",
                "intervention_category",
                "intervention_binary",
                "intervention_dose",
            ],
            "molecular_descriptor": [
                "descriptor_standard",
                "descriptor_standard",
                "descriptor_standard",
                "descriptor_positive",
                "descriptor_positive",
                "descriptor_count",
                "descriptor_bounded",
            ],
        }
        for block_name, families in block_families.items():
            feature_slice = blocks.get(block_name)
            if feature_slice is None or feature_slice.stop <= feature_slice.start:
                continue
            for col in range(feature_slice.start, feature_slice.stop):
                family = str(np.random.choice(families))
                X[:, col] = self._corrosion_marginal_values(X[:, col], family)

        return X

    @staticmethod
    def _sample_block_allocation_from_ranges(
        names: list[str],
        ranges: Any,
        option_name: str,
    ) -> Optional[np.ndarray]:
        if ranges is None:
            return None

        ranges_array = np.asarray(ranges, dtype=float)
        if ranges_array.shape == (2 * len(names),):
            ranges_array = ranges_array.reshape(len(names), 2)
        if ranges_array.shape != (len(names), 2):
            raise ValueError(
                f"{option_name} must contain low/high pairs for {len(names)} weights in "
                f"{', '.join(names)} order."
            )
        if not np.all(np.isfinite(ranges_array)) or np.any(ranges_array < 0.0):
            raise ValueError(f"{option_name} bounds must be finite and non-negative.")

        lows = ranges_array[:, 0]
        highs = ranges_array[:, 1]
        if np.any(lows > highs):
            raise ValueError(f"{option_name} low bounds must be <= high bounds.")
        if lows.sum() > 1.0 + 1e-12 or highs.sum() < 1.0 - 1e-12:
            raise ValueError(f"{option_name} bounds must allow allocations that sum to 1.")

        sampled = np.zeros(len(names), dtype=float)
        remaining = 1.0
        for idx in range(len(names)):
            remaining_low = float(lows[idx + 1 :].sum())
            remaining_high = float(highs[idx + 1 :].sum())
            low = max(float(lows[idx]), remaining - remaining_high)
            high = min(float(highs[idx]), remaining - remaining_low)
            if high < low - 1e-12:
                raise ValueError(f"{option_name} bounds cannot produce a valid allocation.")
            sampled[idx] = low if abs(high - low) <= 1e-12 else float(np.random.uniform(low, high))
            remaining -= sampled[idx]

        sampled[-1] += remaining
        sampled = np.clip(sampled, lows, highs)
        if sampled.sum() <= 0.0:
            raise ValueError(f"At least one {option_name} sampled weight must be positive.")
        return sampled

    def _split_blocks_from_allocation(
        self,
        num_features: int,
        names: list[str],
        allocation: Any,
        option_name: str,
        min_counts: Any = None,
    ) -> Dict[str, slice]:
        if num_features <= 0:
            return {}

        allocation = np.asarray(allocation, dtype=float)
        if allocation.shape != (len(names),):
            raise ValueError(
                f"{option_name} must contain {len(names)} weights in "
                f"{', '.join(names)} order."
            )
        if not np.all(np.isfinite(allocation)) or np.any(allocation < 0.0):
            raise ValueError(f"{option_name} weights must be finite and non-negative.")
        if allocation.sum() <= 0.0:
            raise ValueError(f"At least one {option_name} weight must be positive.")

        weights = allocation / allocation.sum()
        raw_counts = weights * num_features
        counts = np.floor(raw_counts).astype(int)
        counts[weights <= 0.0] = 0

        remaining = int(num_features - counts.sum())
        if remaining > 0:
            for idx in np.argsort(-(raw_counts - counts)):
                if weights[idx] <= 0.0:
                    continue
                counts[idx] += 1
                remaining -= 1
                if remaining == 0:
                    break
        while remaining > 0:
            idx = int(np.argmax(weights))
            counts[idx] += 1
            remaining -= 1

        if min_counts is not None:
            min_counts_array = np.asarray(min_counts, dtype=float)
            if min_counts_array.shape != (len(names),):
                raise ValueError(
                    f"{option_name}_min_counts must contain {len(names)} counts in "
                    f"{', '.join(names)} order."
                )
            if not np.all(np.isfinite(min_counts_array)) or np.any(min_counts_array < 0.0):
                raise ValueError(f"{option_name}_min_counts values must be finite and non-negative.")
            rounded_min_counts = np.rint(min_counts_array)
            if not np.allclose(min_counts_array, rounded_min_counts):
                raise ValueError(f"{option_name}_min_counts values must be whole numbers.")
            min_counts_int = rounded_min_counts.astype(int)
            if np.any((min_counts_int > 0) & (weights <= 0.0)):
                raise ValueError(f"{option_name}_min_counts cannot require columns for zero-weight blocks.")
            if int(min_counts_int.sum()) > num_features:
                raise ValueError(f"{option_name}_min_counts sum cannot exceed the sampled feature count.")

            deficits = np.maximum(min_counts_int - counts, 0)
            if np.any(deficits):
                counts += deficits
                excess = int(counts.sum() - num_features)
                while excess > 0:
                    candidates = np.flatnonzero(counts > min_counts_int)
                    if candidates.size == 0:
                        raise ValueError(f"{option_name}_min_counts cannot be satisfied for this feature count.")
                    over_target = counts[candidates] - raw_counts[candidates]
                    idx = int(candidates[np.argmax(over_target)])
                    counts[idx] -= 1
                    excess -= 1

        blocks: Dict[str, slice] = {}
        start = 0
        for name, width in zip(names, counts.tolist()):
            end = min(num_features, start + width)
            if end > start:
                blocks[name] = slice(start, end)
            start = end
            if start >= num_features:
                break
        return blocks

    def _sample_informed_task_family(self) -> str:
        families = ["normal_corrosion", "inhibitor_agent"]
        probs = np.asarray(self.fixed_hp.get("informed_task_family_probs", (0.85, 0.15)), dtype=float)
        if probs.shape != (len(families),):
            raise ValueError("informed_task_family_probs must contain two weights in normal_corrosion, inhibitor_agent order.")
        if not np.all(np.isfinite(probs)) or np.any(probs < 0.0) or probs.sum() <= 0.0:
            raise ValueError("informed_task_family_probs weights must be finite, non-negative, and not all zero.")
        probs = probs / probs.sum()
        return str(np.random.choice(families, p=probs))

    def _split_informed_blocks_with_family(self, num_features: int) -> Tuple[str, Dict[str, slice]]:
        """Split features into audit-derived corrosion feature blocks."""
        names = [
            "material",
            "environment",
            "process_history",
            "exposure_duration",
            "temporal_history",
            "direct_intervention",
            "molecular_descriptor",
            "electrochem_control",
            "electrochem_downstream",
        ]
        family = self._sample_informed_task_family()
        if family == "inhibitor_agent":
            allocation = self.fixed_hp.get(
                "informed_inhibitor_block_allocation",
                (0.05, 0.08, 0.02, 0.02, 0.0, 0.05, 0.78, 0.0, 0.0),
            )
            option_name = "informed_inhibitor_block_allocation"
        else:
            allocation = self.fixed_hp.get(
                "informed_normal_block_allocation",
                (0.72, 0.22, 0.04, 0.01, 0.0, 0.01, 0.0, 0.0, 0.0),
            )
            option_name = "informed_normal_block_allocation"
        allocation_ranges = self.fixed_hp.get(f"{option_name}_ranges")
        sampled_allocation = self._sample_block_allocation_from_ranges(
            names, allocation_ranges, f"{option_name}_ranges"
        )
        if sampled_allocation is not None:
            allocation = sampled_allocation
        min_counts = self.fixed_hp.get(f"{option_name}_min_counts")
        blocks = self._split_blocks_from_allocation(
            num_features, names, allocation, option_name, min_counts=min_counts
        )
        return family, blocks

    def _split_informed_blocks(self, num_features: int) -> Dict[str, slice]:
        """Split features into audit-derived corrosion feature blocks."""
        _, blocks = self._split_informed_blocks_with_family(num_features)
        return blocks

    def _prepare_epit_latent_scm_context(self, num_features: int) -> EpitLatentSCMContext:
        if not self._empirical_pitting_composition_enabled():
            raise ValueError("Latent EPIT SCM context is only available in empirical composition mode.")
        if not self._fixed_epit_schema_enabled():
            raise ValueError("Empirical EPIT composition currently requires pitting_fixed_epit_schema=True.")
        if not self._is_pitting_profile_name(self._informed_physical_marginal_profile()):
            raise ValueError("Empirical EPIT composition requires the pitting_potential_v1 marginal profile.")
        if self._informed_target_family() != "pitting_potential":
            raise ValueError("Empirical EPIT composition requires informed_target_family='pitting_potential'.")

        family, output_blocks = self._split_informed_blocks_with_family(int(num_features))
        if family != "normal_corrosion":
            raise ValueError("Empirical EPIT composition requires the normal_corrosion task family.")
        material_slice = output_blocks.get("material")
        if material_slice is None or material_slice.stop <= material_slice.start:
            raise ValueError("Empirical EPIT composition requires a material block.")

        profile_name = str(self.fixed_hp.get("pitting_composition_profile", EPIT_COMPOSITION_PROFILE))
        profile = load_epit_composition_profile(profile_name)
        output_material_width = material_slice.stop - material_slice.start
        if output_material_width != len(profile.observed_elements):
            raise ValueError(
                "Empirical EPIT composition requires a fixed material width of "
                f"{len(profile.observed_elements)}, got {output_material_width}."
            )

        latent_count_value = float(self.fixed_hp.get("pitting_material_latent_count", 2))
        if (
            not np.isfinite(latent_count_value)
            or latent_count_value < 1
            or not latent_count_value.is_integer()
        ):
            raise ValueError("pitting_material_latent_count must be a positive integer.")
        latent_count = int(latent_count_value)
        if latent_count > output_material_width:
            raise ValueError(
                "pitting_material_latent_count cannot exceed the number of observed material columns."
            )

        reduction = output_material_width - latent_count
        latent_blocks: Dict[str, slice] = {}
        for name, feature_slice in output_blocks.items():
            if name == "material":
                latent_blocks[name] = slice(feature_slice.start, feature_slice.start + latent_count)
            elif feature_slice.stop <= material_slice.start:
                latent_blocks[name] = feature_slice
            elif feature_slice.start >= material_slice.stop:
                latent_blocks[name] = slice(feature_slice.start - reduction, feature_slice.stop - reduction)
            else:
                raise ValueError(f"Feature block {name!r} overlaps the fixed EPIT material block.")

        scm_num_features = int(num_features) - reduction
        if scm_num_features <= 1:
            raise ValueError("Empirical EPIT latent SCM must contain at least two features.")
        return EpitLatentSCMContext(
            family=family,
            output_blocks=output_blocks,
            latent_blocks=latent_blocks,
            scm_num_features=scm_num_features,
        )

    def _expand_epit_material_latents(
        self,
        X: Tensor,
        context: EpitLatentSCMContext,
    ) -> Tensor:
        latent_slice = context.latent_blocks["material"]
        output_slice = context.output_blocks["material"]
        if latent_slice.start != output_slice.start:
            raise ValueError("Latent and output EPIT material blocks must start at the same column.")
        if X.shape[-1] != context.scm_num_features:
            raise ValueError(
                f"Expected {context.scm_num_features} latent SCM features, got {X.shape[-1]}."
            )

        profile_name = str(self.fixed_hp.get("pitting_composition_profile", EPIT_COMPOSITION_PROFILE))
        profile = load_epit_composition_profile(profile_name)
        latents = X[:, latent_slice].detach().cpu().numpy()
        random_seed = int(np.random.randint(0, np.iinfo(np.int32).max))
        batch = map_epit_latents_to_compositions(
            latents,
            profile=profile,
            family_probabilities=self.fixed_hp.get("pitting_composition_family_probs"),
            perturb_strength=float(self.fixed_hp.get("pitting_composition_perturb_strength", 0.05)),
            random_state=random_seed,
        )
        observed = torch.as_tensor(batch.observed_compositions.copy(), device=X.device, dtype=X.dtype)
        X = torch.cat((X[:, : latent_slice.start], observed, X[:, latent_slice.stop :]), dim=-1)
        if X.shape[-1] != max(feature_slice.stop for feature_slice in context.output_blocks.values()):
            raise ValueError("Expanded empirical EPIT features do not match the requested output schema.")
        self.last_pitting_composition_batch = batch
        return X

    def _apply_empirical_pitting_feature_profile(
        self,
        X: Tensor,
        blocks: Dict[str, slice],
        family: str,
    ) -> Tuple[Tensor, PittingProfileInfo]:
        """Replace the complete fixed EPIT schema with empirical physical rows."""

        if not self._fixed_epit_schema_enabled():
            raise ValueError("empirical_features requires pitting_fixed_epit_schema=True.")
        if family != "normal_corrosion":
            raise ValueError("empirical_features requires the normal_corrosion task family.")
        if self._informed_target_family() != "pitting_potential":
            raise ValueError("empirical_features requires informed_target_family='pitting_potential'.")
        profile_name = str(
            self.fixed_hp.get("pitting_feature_profile", EPIT_FEATURE_PROFILE)
        )
        profile = load_epit_feature_profile(
            profile_name,
            composition_profile_name=str(
                self.fixed_hp.get(
                    "pitting_composition_profile",
                    EPIT_COMPOSITION_PROFILE,
                )
            ),
        )
        expected_feature_count = len(profile.composition_profile.observed_elements) + 4
        if X.ndim != 2 or X.shape[1] != expected_feature_count:
            raise ValueError(
                "empirical_features requires exactly "
                f"{expected_feature_count} generated columns."
            )
        material_slice = blocks.get("material")
        environment_slice = blocks.get("environment")
        process_slice = blocks.get("process_history")
        if material_slice is None or (
            material_slice.stop - material_slice.start
            != len(profile.composition_profile.observed_elements)
        ):
            raise ValueError("empirical_features requires the fixed 24-column material block.")
        if environment_slice is None or environment_slice.stop - environment_slice.start != 3:
            raise ValueError("empirical_features requires temperature, chloride, and pH columns.")
        if process_slice is None or process_slice.stop - process_slice.start != 1:
            raise ValueError("empirical_features requires one test-method column.")

        nonempty_blocks = {
            name
            for name, feature_slice in blocks.items()
            if feature_slice.stop > feature_slice.start
        }
        if nonempty_blocks != {"material", "environment", "process_history"}:
            raise ValueError(
                "empirical_features permits only material, environment, and process blocks."
            )

        expected_category_count = int(
            profile.metadata["evaluator_preprocessing"]["category_count"]
        )
        configured_category_count = self.fixed_hp.get("pitting_process_category_count")
        if configured_category_count is not None:
            configured_value = float(configured_category_count)
            if (
                not np.isfinite(configured_value)
                or not configured_value.is_integer()
                or int(configured_value) != expected_category_count
            ):
                raise ValueError(
                    "empirical_features requires pitting_process_category_count="
                    f"{expected_category_count}."
                )

        configured_family_probabilities = self.fixed_hp.get(
            "pitting_composition_family_probs"
        )
        feature_family_probabilities = None
        if configured_family_probabilities is not None:
            full_probabilities = np.asarray(
                configured_family_probabilities,
                dtype=np.float64,
            )
            expected_shape = (len(profile.composition_profile.families),)
            if full_probabilities.shape != expected_shape:
                raise ValueError(
                    "pitting_composition_family_probs must match the complete composition profile."
                )
            if not np.isfinite(full_probabilities).all() or np.any(full_probabilities < 0.0):
                raise ValueError(
                    "pitting_composition_family_probs must be finite and non-negative."
                )
            feature_family_probabilities = [
                full_probabilities[profile.composition_profile.families.index(name)]
                for name in profile.families
            ]

        random_seed = int(np.random.randint(0, np.iinfo(np.int32).max))
        batch = sample_epit_feature_rows(
            X.shape[0],
            profile=profile,
            composition_family_probabilities=feature_family_probabilities,
            perturb_strength=float(
                self.fixed_hp.get("pitting_composition_perturb_strength", 0.05)
            ),
            random_state=random_seed,
        )
        sampled = torch.as_tensor(batch.features.copy(), device=X.device, dtype=X.dtype)
        X = X.clone()
        sample_slices = epit_feature_slices(
            len(profile.composition_profile.observed_elements)
        )
        X[:, material_slice] = sampled[:, sample_slices["material"]]
        X[:, environment_slice] = sampled[:, sample_slices["environment"]]
        X[:, process_slice] = sampled[:, sample_slices["process_history"]]

        info = PittingProfileInfo(
            applied=True,
            material_style="empirical_feature_profile",
            physical_profile_applied=True,
        )
        for col in range(material_slice.start, material_slice.stop):
            info.add_role("material_empirical_composition", col)
        for role, col in zip(
            ("temperature_like", "chloride_like", "ph_like"),
            range(environment_slice.start, environment_slice.stop),
            strict=True,
        ):
            info.add_role(role, col)
        info.add_role("test_method_category", process_slice.start, categorical=True)
        family_ids = torch.as_tensor(
            batch.composition_family_indices.copy(),
            device=X.device,
            dtype=torch.long,
        )
        info.material_family_ids = family_ids
        self.last_pitting_feature_batch = batch
        self.last_pitting_composition_batch = batch.compositions
        self.last_pitting_material_family_ids = family_ids.detach().cpu()
        return X, info

    @staticmethod
    def _standardize_signal(values: Tensor) -> Tensor:
        values = torch.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0)
        if values.numel() <= 1:
            return torch.zeros_like(values)
        centered = values - values.mean()
        scale = torch.std(centered.float(), unbiased=False).to(device=values.device, dtype=values.dtype)
        return centered / scale.clamp_min(1e-6)

    @staticmethod
    def _standardize_features_for_scm_target(X: Tensor) -> Tensor:
        """Standardize a copy of each generated column for the SCM target head."""
        if X.ndim != 2:
            raise ValueError("SCM target features must be a 2D tensor.")
        clean = torch.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        centered = clean - clean.mean(dim=0, keepdim=True)
        scale = torch.std(clean.float(), dim=0, unbiased=False, keepdim=True).to(
            device=X.device,
            dtype=X.dtype,
        )
        variable = torch.isfinite(scale) & (scale > 1e-6)
        standardized = torch.where(
            variable,
            centered / scale.clamp_min(1e-6),
            torch.zeros_like(centered),
        )
        return torch.nan_to_num(standardized, nan=0.0, posinf=0.0, neginf=0.0)

    @torch.no_grad()
    def _generate_scm_target_from_physical_features(
        self,
        X: Tensor,
        params: Dict[str, Any],
        prior_cls: type[MLPSCM] | type[TreeSCM],
    ) -> Tensor:
        """Map unchanged physical features to a target with a direct SCM head."""
        standardized = self._standardize_features_for_scm_target(X)
        target_params = {
            **params,
            "seq_len": int(X.shape[0]),
            "num_features": int(X.shape[1]),
            "num_outputs": 1,
            "is_causal": False,
            "device": X.device,
        }
        target_prior = prior_cls(**target_params)
        _, target = target_prior(causes=standardized)
        self.last_pitting_scm_target_input = standardized.detach().cpu()
        self.last_pitting_scm_target_metadata = {
            "target_policy": "scm_target_from_standardized_physical_features_v1",
            "scm_prior_type": str(params["prior_type"]),
            "input_standardization": "per_dataset_column_population_zscore",
            "constant_column_policy": "zero",
            "physical_features_modified": False,
        }
        self.last_pitting_target_component = target.detach().cpu()
        self.last_pitting_target_drive = target.detach().cpu()
        return target

    @torch.no_grad()
    def _generate_scm_epit_target_from_physical_features(
        self,
        X: Tensor,
        params: Dict[str, Any],
        prior_cls: type[MLPSCM] | type[TreeSCM],
    ) -> Tensor:
        """Combine a direct SCM target with a calibrated raw-feature EPIT rule."""
        feature_batch = self.last_pitting_feature_batch
        material_feature_count = (
            EPIT_MATERIAL_FEATURE_COUNT
            if feature_batch is None
            else feature_batch.compositions.observed_compositions.shape[1]
        )
        expected_feature_count = material_feature_count + 4
        if X.ndim != 2 or X.shape[1] != expected_feature_count:
            raise ValueError(
                "The empirical SCM+EPIT target requires exactly "
                f"{expected_feature_count} raw physical features."
            )
        target_mix_weight = float(
            self.fixed_hp.get("informed_target_mix_weight", 0.35)
        )
        if (
            not np.isfinite(target_mix_weight)
            or not 0.0 <= target_mix_weight <= 1.0
        ):
            raise ValueError(
                "Informed target mix weight must be finite and between 0 and 1."
            )

        scm_target = self._generate_scm_target_from_physical_features(
            X,
            params,
            prior_cls,
        )
        family_ids = self.last_pitting_material_family_ids
        if family_ids is None or family_ids.numel() != X.shape[0]:
            raise RuntimeError(
                "The empirical physical-feature generator did not provide "
                "material-family metadata for the EPIT target rule."
            )
        profile_info = PittingProfileInfo(
            applied=True,
            material_style="empirical_feature_profile",
            physical_profile_applied=True,
            material_family_ids=family_ids.to(device=X.device),
        )
        blocks = epit_feature_slices(material_feature_count)
        rule = self._sample_fixed_epit_target_rule(
            X,
            blocks,
            target_mix_weight,
            profile_info,
        )
        if rule.get("rule_type") != "fixed_epit_target_rule_v3_weighted_family":
            raise ValueError(
                "empirical_features_scm_target requires calibrated EPIT "
                "target-rule scores."
            )
        target_component, epit_drive = self._evaluate_fixed_epit_target_rule_tensor(
            X,
            rule,
        )
        combined = (
            (1.0 - target_mix_weight) * self._standardize_signal(scm_target)
            + target_component.to(dtype=scm_target.dtype)
        )
        target = self._standardize_signal(combined)

        self.last_pitting_target_rule = rule
        self.last_pitting_target_component = target_component.detach().cpu()
        self.last_pitting_target_drive = epit_drive.detach().cpu()
        self.last_pitting_scm_target_metadata = {
            "target_policy": "standardized_scm_plus_calibrated_epit_v1",
            "scm_prior_type": str(params["prior_type"]),
            "scm_input_standardization": (
                "per_dataset_column_population_zscore"
            ),
            "constant_column_policy": "zero",
            "epit_input_representation": "raw_physical_features",
            "target_mix_weight": target_mix_weight,
            "final_target_standardization": "population_zscore",
            "transformer_input_standardization": (
                "per_dataset_column_population_zscore"
            ),
            "reg2cls_applied": False,
        }
        return target

    def _block_projection(self, X: Tensor, feature_slice: Optional[slice], max_columns: int = 12) -> Optional[Tensor]:
        if feature_slice is None or feature_slice.stop <= feature_slice.start:
            return None

        block = X[:, feature_slice]
        if block.numel() == 0:
            return None

        width = block.shape[-1]
        if width > max_columns:
            idx = torch.randperm(width, device=X.device)[:max_columns]
            block = block[:, idx]
            width = block.shape[-1]

        if width == 1:
            projection = block[:, 0]
        else:
            weights = torch.randn(width, device=X.device, dtype=X.dtype)
            weights = weights / torch.linalg.vector_norm(weights).clamp_min(1e-6)
            projection = block @ weights
        return self._standardize_signal(projection)

    @staticmethod
    def _optional_zero(values: Optional[Tensor], reference: Tensor) -> Tensor:
        return torch.zeros_like(reference) if values is None else values

    def _informed_target_family(self) -> str:
        family = str(self.fixed_hp.get("informed_target_family", "generic_corrosion")).strip().lower()
        family = family.replace("-", "_")
        aliases = {
            "generic": "generic_corrosion",
            "corrosion": "generic_corrosion",
            "corrosion_severity": "generic_corrosion",
            "pitting": "pitting_potential",
            "epit": "pitting_potential",
            "breakdown_potential": "pitting_potential",
            "pitting_breakdown_potential": "pitting_potential",
            "datacor": "inhibitor_efficiency",
            "efficiency": "inhibitor_efficiency",
            "inhibitor": "inhibitor_efficiency",
            "inhibition_efficiency": "inhibitor_efficiency",
            "protection_efficiency": "inhibitor_efficiency",
        }
        family = aliases.get(family, family)
        if family not in {"generic_corrosion", "pitting_potential", "inhibitor_efficiency"}:
            raise ValueError(
                "Unsupported informed_target_family "
                f"{family!r}. Expected one of: generic_corrosion, pitting_potential, inhibitor_efficiency."
            )
        return family

    def _environment_aggressiveness(self, X: Tensor, blocks: Dict[str, slice], reference: Tensor) -> Tensor:
        env_slice = blocks.get("environment")
        env_primary = self._block_projection(X, env_slice)
        if env_primary is None:
            return torch.zeros_like(reference)

        env_secondary = self._optional_zero(self._block_projection(X, env_slice), env_primary)
        env_tertiary = self._optional_zero(self._block_projection(X, env_slice), env_primary)

        chloride_like = torch.sigmoid(env_primary)
        pH_stress_like = torch.abs(torch.tanh(env_secondary))
        temperature_like = torch.sigmoid(env_tertiary)
        aggressiveness = 0.50 * chloride_like + 0.30 * pH_stress_like + 0.20 * temperature_like
        return self._standardize_signal(aggressiveness)

    def _apply_informed_inhibitor_efficiency_mechanism(
        self,
        X: Tensor,
        y: Tensor,
        blocks: Dict[str, slice],
        interaction_strength: float,
        intervention_strength: float,
        profile_info: Optional[InhibitorEfficiencyProfileInfo] = None,
    ) -> Tuple[Tensor, Tensor]:
        """Add an inhibitor-efficiency target where higher y means better protection."""
        reference = y.to(dtype=X.dtype)
        profile_applied = profile_info is not None and profile_info.applied

        descriptor = (
            profile_info.descriptor_efficacy
            if profile_applied and profile_info.descriptor_efficacy is not None
            else self._block_projection(X, blocks.get("molecular_descriptor"))
        )
        environment = (
            profile_info.environment_modifier
            if profile_applied and profile_info.environment_modifier is not None
            else self._environment_aggressiveness(X, blocks, reference)
        )
        material = (
            profile_info.material_modifier
            if profile_applied and profile_info.material_modifier is not None
            else self._block_projection(X, blocks.get("material"))
        )
        intervention = (
            profile_info.intervention_signal
            if profile_applied and profile_info.intervention_signal is not None
            else self._block_projection(X, blocks.get("direct_intervention"))
        )

        if descriptor is None and intervention is None:
            return X, y

        descriptor_signal = self._optional_zero(descriptor, reference)
        descriptor_effect = torch.tanh(descriptor_signal)
        dose = torch.sigmoid(self._optional_zero(intervention, reference)) if intervention is not None else None
        environment_signal = self._optional_zero(environment, reference)
        environment_effect = torch.tanh(environment_signal)
        environment_gate = torch.sigmoid(environment_signal)
        material_signal = self._optional_zero(material, reference)
        material_effect = torch.tanh(material_signal)
        material_gate = torch.sigmoid(material_signal)

        descriptor_coef = float(
            self.fixed_hp.get(
                "inhibitor_descriptor_coef",
                0.65 * float(self.fixed_hp.get("inhibitor_descriptor_coef_scale", 1.0)),
            )
        )
        context_coef = float(
            self.fixed_hp.get(
                "inhibitor_context_coef",
                0.14 * float(self.fixed_hp.get("inhibitor_context_coef_scale", 1.0)),
            )
        )
        environment_interaction_coef = float(
            self.fixed_hp.get(
                "inhibitor_environment_interaction_coef",
                0.365 * float(self.fixed_hp.get("inhibitor_environment_interaction_coef_scale", 1.0)),
            )
        )
        material_interaction_coef = float(
            self.fixed_hp.get(
                "inhibitor_material_interaction_coef",
                0.24 * float(self.fixed_hp.get("inhibitor_material_interaction_coef_scale", 1.0)),
            )
        )
        intervention_coef = float(
            self.fixed_hp.get(
                "inhibitor_intervention_coef",
                0.375 * float(self.fixed_hp.get("inhibitor_intervention_coef_scale", 1.0)),
            )
        )
        coefficients = np.asarray(
            [
                descriptor_coef,
                context_coef,
                environment_interaction_coef,
                material_interaction_coef,
                intervention_coef,
            ],
            dtype=float,
        )
        if not np.all(np.isfinite(coefficients)) or np.any(coefficients < 0.0):
            raise ValueError("Inhibitor coefficients must be finite and non-negative.")

        inhibitor_drive = descriptor_coef * descriptor_effect
        if blocks.get("environment") is not None:
            inhibitor_drive = inhibitor_drive + context_coef * environment_effect
            inhibitor_drive = inhibitor_drive + interaction_strength * environment_interaction_coef * (
                descriptor_effect * environment_effect
            )
        if material is not None:
            inhibitor_drive = inhibitor_drive + 0.75 * context_coef * material_effect
            inhibitor_drive = inhibitor_drive + interaction_strength * material_interaction_coef * (
                descriptor_effect * material_effect
            )
        if dose is not None:
            inhibitor_drive = inhibitor_drive + intervention_coef * dose * (
                0.70 + 0.20 * environment_gate + 0.10 * material_gate
            )

        if torch.std(inhibitor_drive.float(), unbiased=False) > 1e-6:
            y = y + intervention_strength * self._standardize_signal(inhibitor_drive).to(dtype=y.dtype)

        return X, y

    def _apply_informed_pitting_potential_mechanism(
        self,
        X: Tensor,
        y: Tensor,
        blocks: Dict[str, slice],
        family: str,
        interaction_strength: float,
        target_mix_weight: float,
        intervention_strength: float,
        profile_info: Optional[PittingProfileInfo] = None,
    ) -> Tuple[Tensor, Tensor]:
        """Add an Epit-like target where higher y means stronger pitting resistance."""
        reference = y.to(dtype=X.dtype)
        generic_target = self._standardize_signal(y)
        if not np.isfinite(target_mix_weight) or not 0.0 <= target_mix_weight <= 1.0:
            raise ValueError("Informed target mix weight must be finite and between 0 and 1.")
        profile_applied = profile_info is not None and profile_info.applied
        if self._fixed_epit_schema_enabled():
            fe_ni_target_only = self._fe_ni_softmax_pitting_composition_enabled()
            empirical_features_target_only = (
                self._pitting_composition_mode() == "empirical_features"
            )
            epit_target_only = fe_ni_target_only or empirical_features_target_only
            effective_mix_weight = 1.0 if epit_target_only else target_mix_weight
            rule = self._sample_fixed_epit_target_rule(
                X, blocks, effective_mix_weight, profile_info
            )
            if epit_target_only:
                rule.update(
                    {
                        "configured_target_mix_weight": float(target_mix_weight),
                        "target_mix_policy": (
                            "epit_only_for_empirical_features"
                            if empirical_features_target_only
                            else "epit_only_for_fe_ni_softmax"
                        ),
                    }
                )
            target_component, epit_drive = self._evaluate_fixed_epit_target_rule_tensor(X, rule)
            self.last_pitting_target_rule = rule
            self.last_pitting_target_component = target_component.detach().cpu()
            self.last_pitting_target_drive = epit_drive.detach().cpu()
            if torch.std(epit_drive.float(), unbiased=False) > 1e-6:
                y = (
                    target_component.to(dtype=y.dtype)
                    if epit_target_only
                    else (1.0 - effective_mix_weight) * generic_target
                    + target_component.to(dtype=y.dtype)
                )
            elif epit_target_only:
                y = torch.zeros_like(generic_target)
            else:
                y = generic_target
            return X, y

        material = (
            profile_info.material_passivity
            if profile_applied and profile_info.material_passivity is not None
            else self._block_projection(X, blocks.get("material"))
        )
        susceptibility = (
            profile_info.material_susceptibility
            if profile_applied and profile_info.material_susceptibility is not None
            else None
        )
        environment = (
            profile_info.environment_aggressiveness
            if profile_applied and profile_info.environment_aggressiveness is not None
            else self._environment_aggressiveness(X, blocks, reference)
        )
        process = (
            profile_info.process_offset
            if profile_applied and profile_info.process_offset is not None
            else self._block_projection(X, blocks.get("process_history"))
        )
        exposure = (
            profile_info.exposure_damage
            if profile_applied and profile_info.exposure_damage is not None
            else self._block_projection(X, blocks.get("exposure_duration"))
        )
        history = self._block_projection(X, blocks.get("temporal_history"))
        intervention = (
            profile_info.intervention_signal
            if profile_applied and profile_info.intervention_signal is not None
            else self._block_projection(X, blocks.get("direct_intervention"))
        )
        descriptor = (
            profile_info.descriptor_signal
            if profile_applied and profile_info.descriptor_signal is not None
            else self._block_projection(X, blocks.get("molecular_descriptor"))
        )

        material_signal = self._optional_zero(material, reference)
        material_passivity = torch.tanh(material_signal)
        if susceptibility is None:
            material_susceptibility = torch.sigmoid(-material_signal)
        else:
            material_susceptibility = torch.sigmoid(self._standardize_signal(susceptibility))
        environment_drive = torch.sigmoid(environment)
        process_offset = torch.tanh(self._optional_zero(process, reference))
        exposure_drive = torch.sigmoid(self._optional_zero(exposure, reference))
        history_damage = torch.sigmoid(self._optional_zero(history, reference))

        material_coef = float(self.fixed_hp.get("epit_material_coef", 0.575))
        environment_coef = float(self.fixed_hp.get("epit_environment_coef", 0.50))
        interaction_coef = float(self.fixed_hp.get("epit_interaction_coef", 0.775))
        coefficients = np.asarray([material_coef, environment_coef, interaction_coef], dtype=float)
        if not np.all(np.isfinite(coefficients)) or np.any(coefficients < 0.0):
            raise ValueError("Epit coefficients must be finite and non-negative.")
        exposure_coef = float(np.random.uniform(0.12, 0.28))
        process_coef = float(np.random.uniform(0.12, 0.28))
        history_coef = float(np.random.uniform(0.08, 0.20))
        descriptor_coef = float(np.random.uniform(0.03, 0.10))

        # Epit is a breakdown threshold: protective/passivating material signal raises it,
        # while aggressive environments and susceptible-material interactions lower it.
        epit_drive = torch.zeros_like(reference)
        if material is not None:
            epit_drive = epit_drive + material_coef * material_passivity
        if blocks.get("environment") is not None:
            epit_drive = epit_drive - environment_coef * environment_drive
        if material is not None and blocks.get("environment") is not None:
            epit_drive = epit_drive - interaction_coef * material_susceptibility * environment_drive
        if exposure is not None:
            epit_drive = epit_drive - exposure_coef * exposure_drive * (0.75 + 0.50 * environment_drive)
        if process is not None:
            epit_drive = epit_drive + process_coef * process_offset * (0.75 + 0.25 * environment_drive)
        if history is not None:
            epit_drive = epit_drive - history_coef * history_damage
        if descriptor is not None and family != "inhibitor_agent":
            epit_drive = epit_drive + descriptor_coef * torch.tanh(descriptor)

        if torch.std(epit_drive.float(), unbiased=False) > 1e-6:
            informed_target = self._standardize_signal(epit_drive).to(dtype=y.dtype)
            y = (1.0 - target_mix_weight) * generic_target + target_mix_weight * informed_target
        else:
            y = generic_target

        electro_signal = torch.tanh(self._standardize_signal(epit_drive)).unsqueeze(-1)
        for electro_name in ("electrochem_control", "electrochem_downstream"):
            electro_slice = blocks.get(electro_name)
            if electro_slice is not None and electro_slice.stop > electro_slice.start:
                X[:, electro_slice] = X[:, electro_slice] + 0.5 * interaction_strength * electro_signal

        if family == "inhibitor_agent":
            if descriptor is None and intervention is None:
                return X, y
            descriptor_efficacy = torch.sigmoid(self._optional_zero(descriptor, reference))
            dose = torch.sigmoid(self._optional_zero(intervention, reference))
            protection = descriptor_efficacy * dose * (0.70 + 0.30 * environment_drive)
            if torch.std(protection.float(), unbiased=False) > 1e-6:
                y = y + intervention_strength * self._standardize_signal(protection).to(dtype=y.dtype)
        elif intervention is not None:
            protection = torch.sigmoid(intervention) * (0.60 + 0.40 * environment_drive)
            if torch.std(protection.float(), unbiased=False) > 1e-6:
                y = y + intervention_strength * self._standardize_signal(protection).to(dtype=y.dtype)

        return X, y

    def _apply_informed_corrosion_mechanism(
        self,
        X: Tensor,
        y: Tensor,
        blocks: Dict[str, slice],
        family: str,
        interaction_strength: float,
        intervention_strength: float,
        target_mix_weight: Optional[float] = None,
        profile_info: Optional[Union[PittingProfileInfo, InhibitorEfficiencyProfileInfo]] = None,
    ) -> Tuple[Tensor, Tensor]:
        """Add a broad corrosion-domain target mechanism over semantic blocks."""
        target_family = self._informed_target_family()
        if target_family == "pitting_potential":
            pitting_info = profile_info if isinstance(profile_info, PittingProfileInfo) else None
            if target_mix_weight is None:
                target_mix_weight = float(self.fixed_hp.get("informed_target_mix_weight", 0.35))
            return self._apply_informed_pitting_potential_mechanism(
                X,
                y,
                blocks,
                family,
                interaction_strength=interaction_strength,
                target_mix_weight=target_mix_weight,
                intervention_strength=intervention_strength,
                profile_info=pitting_info,
            )
        if target_family == "inhibitor_efficiency":
            inhibitor_info = profile_info if isinstance(profile_info, InhibitorEfficiencyProfileInfo) else None
            return self._apply_informed_inhibitor_efficiency_mechanism(
                X,
                y,
                blocks,
                interaction_strength=interaction_strength,
                intervention_strength=intervention_strength,
                profile_info=inhibitor_info,
            )

        reference = y.to(dtype=X.dtype)
        material = self._block_projection(X, blocks.get("material"))
        environment = self._environment_aggressiveness(X, blocks, reference)
        process = self._block_projection(X, blocks.get("process_history"))
        exposure = self._block_projection(X, blocks.get("exposure_duration"))
        history = self._block_projection(X, blocks.get("temporal_history"))
        intervention = self._block_projection(X, blocks.get("direct_intervention"))
        descriptor = self._block_projection(X, blocks.get("molecular_descriptor"))

        material_susceptibility = torch.tanh(self._optional_zero(material, reference))
        environment_drive = torch.sigmoid(environment)
        process_modifier = torch.tanh(self._optional_zero(process, reference))
        exposure_drive = torch.sigmoid(self._optional_zero(exposure, reference))
        history_damage = torch.sigmoid(self._optional_zero(history, reference))

        corrosion_drive = torch.zeros_like(reference)
        if material is not None:
            corrosion_drive = corrosion_drive + 0.35 * material_susceptibility
        if blocks.get("environment") is not None:
            corrosion_drive = corrosion_drive + 0.45 * environment_drive
        if material is not None and blocks.get("environment") is not None:
            corrosion_drive = corrosion_drive + 0.75 * material_susceptibility * environment_drive
        if exposure is not None:
            corrosion_drive = corrosion_drive + 0.25 * exposure_drive * (0.75 + 0.50 * environment_drive)
        if process is not None:
            corrosion_drive = corrosion_drive + 0.20 * process_modifier * (0.75 + 0.25 * environment_drive)
        if history is not None:
            corrosion_drive = corrosion_drive + 0.20 * history_damage

        if descriptor is not None and family != "inhibitor_agent":
            # Descriptor-heavy columns can appear in mixed real tasks, but in normal
            # corrosion tasks they should not dominate the target.
            corrosion_drive = corrosion_drive + 0.08 * torch.tanh(descriptor)

        if torch.std(corrosion_drive.float(), unbiased=False) > 1e-6:
            y = y + interaction_strength * self._standardize_signal(corrosion_drive).to(dtype=y.dtype)

        electro_signal = torch.tanh(self._standardize_signal(corrosion_drive)).unsqueeze(-1)
        for electro_name in ("electrochem_control", "electrochem_downstream"):
            electro_slice = blocks.get(electro_name)
            if electro_slice is not None and electro_slice.stop > electro_slice.start:
                X[:, electro_slice] = X[:, electro_slice] + 0.5 * interaction_strength * electro_signal

        if family == "inhibitor_agent":
            if descriptor is None and intervention is None:
                return X, y
            descriptor_efficacy = torch.sigmoid(self._optional_zero(descriptor, reference))
            dose = torch.sigmoid(self._optional_zero(intervention, reference))
            inhibitor_effect = descriptor_efficacy * dose * (0.70 + 0.30 * environment_drive)
            if torch.std(inhibitor_effect.float(), unbiased=False) > 1e-6:
                y = y - intervention_strength * self._standardize_signal(inhibitor_effect).to(dtype=y.dtype)
        elif intervention is not None:
            intervention_gate = torch.sigmoid(intervention)
            inhibitor_effect = intervention_gate * (0.60 + 0.40 * environment_drive)
            if torch.std(inhibitor_effect.float(), unbiased=False) > 1e-6:
                y = y - intervention_strength * self._standardize_signal(inhibitor_effect).to(dtype=y.dtype)

        return X, y

    def apply_informed_structure(
        self,
        X: Tensor,
        y: Tensor,
        params: Dict[str, Any],
        *,
        epit_latent_context: Optional[EpitLatentSCMContext] = None,
    ) -> Tuple[Tensor, Tensor]:
        """Inject block-wise and interaction structure for informed synthetic priors."""
        num_features = int(params["num_features"])
        if num_features <= 1:
            return X, y

        if epit_latent_context is None:
            family, blocks = self._split_informed_blocks_with_family(num_features)
            structure_blocks = blocks
        else:
            family = epit_latent_context.family
            blocks = epit_latent_context.output_blocks
            structure_blocks = epit_latent_context.latent_blocks
        if not blocks:
            return X, y

        X = X.clone()
        y = y.clone()
        self.last_pitting_target_rule = None
        self.last_pitting_target_component = None
        self.last_pitting_target_drive = None
        self.last_pitting_composition_batch = None
        self.last_pitting_feature_batch = None
        self.last_pitting_material_family_ids = None
        self.last_pitting_scm_target_input = None
        self.last_pitting_scm_target_metadata = None

        if self._empirical_pitting_scm_target_enabled():
            if epit_latent_context is not None:
                raise ValueError(
                    "empirical_features_scm_target does not use SCM material latents."
                )
            profile = self._informed_physical_marginal_profile()
            if not self._is_pitting_profile_name(profile):
                raise ValueError(
                    "empirical_features_scm_target requires the "
                    "pitting_potential_v1 profile."
                )
            X, _ = self._apply_empirical_pitting_feature_profile(
                X,
                blocks,
                family,
            )
            return torch.nan_to_num(X), torch.zeros_like(y)

        block_strength = float(self.fixed_hp.get("informed_feature_block_strength", 0.30))
        block_strength = float(np.clip(block_strength, 0.0, 0.95))
        interaction_strength = float(self.fixed_hp.get("informed_interaction_strength", 0.35))
        target_mix_weight = float(self.fixed_hp.get("informed_target_mix_weight", 0.35))
        history_strength = float(self.fixed_hp.get("informed_history_strength", 0.70))
        history_strength = float(np.clip(history_strength, 0.0, 0.99))
        intervention_strength = float(self.fixed_hp.get("informed_intervention_strength", 0.20))

        # Features in the same block share a latent component.
        for feature_slice in structure_blocks.values():
            if feature_slice.stop - feature_slice.start <= 1:
                continue
            shared = torch.randn(X.shape[0], 1, device=X.device, dtype=X.dtype)
            X[:, feature_slice] = (1.0 - block_strength) * X[:, feature_slice] + block_strength * shared

        # Path dependence is limited to true temporal-history features.
        history_slice = structure_blocks.get("temporal_history")
        if history_slice is not None and history_slice.stop > history_slice.start and X.shape[0] > 2:
            hist = X[:, history_slice].clone()
            for t in range(1, hist.shape[0]):
                hist[t] = history_strength * hist[t - 1] + (1.0 - history_strength) * hist[t]
            X[:, history_slice] = hist
            y = y + 0.2 * hist.mean(dim=-1)

        if epit_latent_context is not None:
            X = self._expand_epit_material_latents(X, epit_latent_context)

        profile = self._informed_physical_marginal_profile()
        if (
            self._empirical_pitting_feature_profile_enabled()
            and not self._is_pitting_profile_name(profile)
        ):
            raise ValueError("empirical_features requires the pitting_potential_v1 profile.")
        if self._is_pitting_profile_name(profile):
            if self._empirical_pitting_feature_profile_enabled():
                X, profile_info = self._apply_empirical_pitting_feature_profile(
                    X,
                    blocks,
                    family,
                )
            else:
                X, profile_info = self._apply_pitting_potential_profile(X, blocks, family)
            X, y = self._apply_informed_corrosion_mechanism(
                X,
                y,
                blocks,
                family,
                interaction_strength=interaction_strength,
                intervention_strength=intervention_strength,
                target_mix_weight=target_mix_weight,
                profile_info=profile_info,
            )
        elif self._is_inhibitor_efficiency_profile_name(profile):
            X, profile_info = self._apply_inhibitor_efficiency_profile(X, blocks, family)
            X, y = self._apply_informed_corrosion_mechanism(
                X,
                y,
                blocks,
                family,
                interaction_strength=interaction_strength,
                intervention_strength=intervention_strength,
                target_mix_weight=target_mix_weight,
                profile_info=profile_info,
            )
        else:
            X, y = self._apply_informed_corrosion_mechanism(
                X,
                y,
                blocks,
                family,
                interaction_strength=interaction_strength,
                intervention_strength=intervention_strength,
                target_mix_weight=target_mix_weight,
            )
            X = self.apply_informed_physical_marginals(X, blocks)

        return torch.nan_to_num(X), torch.nan_to_num(y)

    @torch.no_grad()
    def generate_dataset(self, params: Dict[str, Any]) -> Tuple[Tensor, Tensor, Tensor]:
        """Generate a single valid dataset based on the provided parameters.

        Parameters
        ----------
        params : dict
            Hyperparameters for generating this specific dataset, including seq_len,
            train_size, num_features, num_classes, prior_type, device, etc.

        Returns
        -------
        X : Tensor
            Features tensor of shape ``(seq_len, max_features)``.

        y : Tensor
            Labels tensor of shape ``(seq_len,)``.

        d : Tensor
            Number of active features after filtering (scalar Tensor).
        """

        if params["prior_type"] == "mlp_scm":
            prior_cls = MLPSCM
        elif params["prior_type"] == "tree_scm":
            prior_cls = TreeSCM
        else:
            raise ValueError(f"Unknown prior type {params['prior_type']}")

        while True:
            generation_params = self._pitting_magpie_base_params(params)
            epit_latent_context = None
            scm_params = generation_params
            if generation_params.get("informed_mode", False) and self._empirical_pitting_composition_enabled():
                epit_latent_context = self._prepare_epit_latent_scm_context(
                    int(generation_params["num_features"])
                )
                scm_params = {
                    **generation_params,
                    "num_features": epit_latent_context.scm_num_features,
                }

            empirical_scm_target = bool(
                generation_params.get("informed_mode", False)
                and self._empirical_pitting_scm_target_enabled()
            )
            if empirical_scm_target:
                X = torch.zeros(
                    int(generation_params["seq_len"]),
                    int(generation_params["num_features"]),
                    device=generation_params["device"],
                )
                y = torch.zeros(
                    int(generation_params["seq_len"]),
                    device=generation_params["device"],
                )
            else:
                X, y = prior_cls(**scm_params)()
            reg2cls_params = params
            if generation_params.get("informed_mode", False):
                X, y = self.apply_informed_structure(
                    X,
                    y,
                    generation_params,
                    epit_latent_context=epit_latent_context,
                )
                profile = self._informed_physical_marginal_profile()
                if self._is_pitting_profile_name(profile) or self._is_inhibitor_efficiency_profile_name(profile):
                    reg2cls_params = {**params, "cat_prob": 0.0}
            if empirical_scm_target:
                y = self._generate_scm_epit_target_from_physical_features(
                    X,
                    generation_params,
                    prior_cls,
                )
            if self._pitting_magpie_features_enabled() and generation_params.get("informed_mode", False):
                X = append_magpie_descriptors_torch(X)
            active_feature_count = int(X.shape[-1])
            if empirical_scm_target:
                X = self._standardize_features_for_scm_target(X)
            else:
                X, y = Reg2Cls(reg2cls_params)(X, y)

            # Add batch dim for single dataset to be compatible with delete_unique_features and sanity_check
            X, y = X.unsqueeze(0), y.unsqueeze(0)
            d = torch.tensor([active_feature_count], device=self.device, dtype=torch.long)

            # Only keep valid datasets with sufficient features and usable targets.
            preserve_fixed_epit_schema = (
                generation_params.get("informed_mode", False)
                and self._empirical_pitting_feature_profile_enabled()
            )
            if not preserve_fixed_epit_schema:
                X, d = self.delete_unique_features(X, d)
            if params["num_classes"] == 0:
                valid_target = self.regression_sanity_check(X, y, params["train_size"])
            else:
                valid_target = self.sanity_check(X, y, params["train_size"])
            if (d > 0).all() and valid_target:
                return X.squeeze(0), y.squeeze(0), d.squeeze(0)

    @torch.no_grad()
    def get_batch(self, batch_size: Optional[int] = None) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
        """Generate a batch of datasets by first creating a parameter list and then processing it.

        Parameters
        ----------
        batch_size : int, optional
            Batch size override. If None, uses self.batch_size.

        Returns
        -------
        X : Tensor or NestedTensor
            Features tensor. If seq_len_per_gp=False, shape is
            ``(batch_size, seq_len, max_features)``.
            If seq_len_per_gp=True, returns a NestedTensor.

        y : Tensor or NestedTensor
            Labels tensor. If seq_len_per_gp=False, shape is ``(batch_size, seq_len)``.
            If seq_len_per_gp=True, returns a NestedTensor.

        d : Tensor
            Number of active features per dataset after filtering, shape ``(batch_size,)``.

        seq_lens : Tensor
            Sequence length for each dataset, shape ``(batch_size,)``.

        train_sizes : Tensor
            Position for train/test split for each dataset, shape ``(batch_size,)``.
        """
        batch_size = batch_size or self.batch_size

        # Calculate number of groups and subgroups
        size_per_gp = min(self.batch_size_per_gp, batch_size)
        num_gps = math.ceil(batch_size / size_per_gp)

        size_per_subgp = min(self.batch_size_per_subgp, size_per_gp)

        # Generate parameters list for all datasets, preserving group and subgroup structure
        param_list = []
        global_seq_len = None
        global_train_size = None

        # Determine global seq_len/train_size if not per-group
        if not self.seq_len_per_gp:
            global_seq_len = self.sample_seq_len(
                self.min_seq_len, self.max_seq_len, log=self.log_seq_len, replay_small=self.replay_small
            )
            global_train_size = self.sample_train_size(self.min_train_size, self.max_train_size, global_seq_len)

        # Generate parameters for each group
        for gp_idx in range(num_gps):
            # Determine actual size for this group (may be smaller for the last group)
            actual_gp_size = min(size_per_gp, batch_size - gp_idx * size_per_gp)
            if actual_gp_size <= 0:
                break

            group_sampled_hp = self.hp_sampling()
            # If per-group, sample seq_len and train_size for this group. Otherwise, use global ones
            if self.seq_len_per_gp:
                gp_seq_len = self.sample_seq_len(
                    self.min_seq_len, self.max_seq_len, log=self.log_seq_len, replay_small=self.replay_small
                )
                gp_train_size = self.sample_train_size(self.min_train_size, self.max_train_size, gp_seq_len)
                # Adjust max features based on seq_len for this group
                gp_max_features = self.adjust_max_features(gp_seq_len, self.max_features)
            else:
                gp_seq_len = global_seq_len
                gp_train_size = global_train_size
                gp_max_features = self.max_features

            # Calculate number of subgroups for this group
            num_subgps_in_gp = math.ceil(actual_gp_size / size_per_subgp)

            # Generate parameters for each subgroup
            for subgp_idx in range(num_subgps_in_gp):
                # Determine actual size for this subgroup
                actual_subgp_size = min(size_per_subgp, actual_gp_size - subgp_idx * size_per_subgp)
                if actual_subgp_size <= 0:
                    break

                # Subgroups share prior type, number of features, and sampled HPs
                subgp_prior_type, subgp_informed_mode = self.get_prior()
                subgp_num_features = round(np.random.uniform(self.min_features, gp_max_features))
                subgp_sampled_hp = {k: v() if callable(v) else v for k, v in group_sampled_hp.items()}

                # Generate parameters for each dataset in this subgroup
                for ds_idx in range(actual_subgp_size):
                    # Each classification dataset has its own class count; regression uses 0.
                    if self.max_classes == 0:
                        ds_num_classes = 0
                    elif np.random.random() > 0.5:
                        ds_num_classes = np.random.randint(2, self.max_classes + 1)
                    else:
                        ds_num_classes = 2

                    # Create parameters dictionary for this dataset
                    params = {
                        **self.fixed_hp,  # Fixed HPs
                        "seq_len": gp_seq_len,
                        "train_size": gp_train_size,
                        # If per-gp setting, use adjusted max features for this group because we use nested tensors
                        # If not per-gp setting, use global max features to fix size for concatenation
                        "max_features": gp_max_features if self.seq_len_per_gp else self.max_features,
                        **subgp_sampled_hp,  # sampled HPs for this group
                        "prior_type": subgp_prior_type,
                        "informed_mode": subgp_informed_mode,
                        "num_features": subgp_num_features,
                        "num_classes": ds_num_classes,
                        "device": self.device,
                    }
                    param_list.append(params)

        # Use joblib to generate datasets in parallel.
        # When PriorDataset runs inside a DataLoader worker, we're already in a multiprocessing
        # context, so loky would be downgraded to n_jobs=1. In that nested case we switch to the
        # threading backend to preserve on-the-fly parallelism and DataLoader overlap.
        if self.n_jobs > 1 and self.device == "cpu":
            worker_info = get_worker_info()
            backend = "threading" if worker_info is not None else "loky"
            parallel_config = {"n_jobs": self.n_jobs, "backend": backend}
            if backend == "loky":
                parallel_config["inner_max_num_threads"] = self.num_threads_per_generate

            with joblib.parallel_config(**parallel_config):
                results = joblib.Parallel()(joblib.delayed(self.generate_dataset)(params) for params in param_list)
        else:
            results = [self.generate_dataset(params) for params in param_list]

        X_list, y_list, d_list = zip(*results)

        # Combine Results
        if self.seq_len_per_gp:
            # Use nested tensors for variable sequence lengths
            X = nested_tensor([x.to(self.device) for x in X_list], device=self.device)
            y = nested_tensor([y.to(self.device) for y in y_list], device=self.device)
        else:
            # Stack into regular tensors for fixed sequence length
            X = torch.stack(X_list).to(self.device)  # (B, T, H)
            y = torch.stack(y_list).to(self.device)  # (B, T)

        # Metadata (always regular tensors)
        d = torch.stack(d_list).to(self.device)  # Actual number of features after filtering out constant ones
        seq_lens = torch.tensor([params["seq_len"] for params in param_list], device=self.device, dtype=torch.long)
        train_sizes = torch.tensor(
            [params["train_size"] for params in param_list], device=self.device, dtype=torch.long
        )

        return X, y, d, seq_lens, train_sizes

    def get_prior(self) -> Tuple[str, bool]:
        """Determine which base prior to use and whether informed structure is enabled.

        Returns
        -------
        tuple[str, bool]
            (selected prior type, informed_mode)
        """
        if self.prior_type == "mix_scm":
            return np.random.choice(["mlp_scm", "tree_scm"], p=self._get_prior_mix_probs(informed=False)), False
        if self.prior_type == "informed_scm":
            return np.random.choice(["mlp_scm", "tree_scm"], p=self._get_prior_mix_probs(informed=True)), True
        if self.prior_type == "hybrid_scm":
            informed_mode = bool(np.random.random() < self.informed_prior_ratio)
            probs = self._get_prior_mix_probs(informed=informed_mode)
            return np.random.choice(["mlp_scm", "tree_scm"], p=probs), informed_mode
        return self.prior_type, False


class DummyPrior(Prior):
    """Create purely random data for testing and debugging.

    This is useful for testing and debugging without the computational overhead
    of SCM-based generation.

    Parameters
    ----------
    batch_size : int, default=256
        Number of datasets to generate.

    min_features : int, default=2
        Minimum number of features per dataset.

    max_features : int, default=100
        Maximum number of features per dataset.

    max_classes : int, default=10
        Maximum number of target classes.

    min_seq_len : int, optional
        Minimum samples per dataset. If None, uses max_seq_len directly.

    max_seq_len : int, default=1024
        Maximum samples per dataset.

    log_seq_len : bool, default=False
        If True, sample sequence length from a log-uniform distribution.

    min_train_size : int or float, default=0.1
        Position or ratio for train/test split start. If int, absolute position.
        If float between 0 and 1, specifies a fraction of sequence length.

    max_train_size : int or float, default=0.9
        Position or ratio for train/test split end. If int, absolute position.
        If float between 0 and 1, specifies a fraction of sequence length.

    device : str, default="cpu"
        Computation device.
    """

    def __init__(
        self,
        batch_size: int = 256,
        min_features: int = 2,
        max_features: int = 100,
        max_classes: int = 10,
        min_seq_len: Optional[int] = None,
        max_seq_len: int = 1024,
        log_seq_len: bool = False,
        min_train_size: Union[int, float] = 0.1,
        max_train_size: Union[int, float] = 0.9,
        device: str = "cpu",
    ):
        super().__init__(
            batch_size=batch_size,
            min_features=min_features,
            max_features=max_features,
            max_classes=max_classes,
            min_seq_len=min_seq_len,
            max_seq_len=max_seq_len,
            log_seq_len=log_seq_len,
            min_train_size=min_train_size,
            max_train_size=max_train_size,
        )
        self.device = device

    @torch.no_grad()
    def get_batch(self, batch_size: Optional[int] = None) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
        """Generate a batch of random datasets for testing purposes.

        Parameters
        ----------
        batch_size : int, optional
            Batch size override, if None, uses self.batch_size.

        Returns
        -------
        X : Tensor
            Features tensor of shape ``(batch_size, seq_len, max_features)``.
            Contains random Gaussian values for all features.

        y : Tensor
            Labels tensor of shape ``(batch_size, seq_len)``.
            Contains randomly assigned class labels.

        d : Tensor
            Number of features per dataset of shape ``(batch_size,)``.
            Always set to max_features for DummyPrior.

        seq_lens : Tensor
            Sequence length for each dataset of shape ``(batch_size,)``.
            All datasets share the same sequence length.

        train_sizes : Tensor
            Position for train/test split for each dataset of shape ``(batch_size,)``.
            All datasets share the same split position.
        """

        batch_size = batch_size or self.batch_size
        seq_len = self.sample_seq_len(self.min_seq_len, self.max_seq_len, log=self.log_seq_len)
        train_size = self.sample_train_size(self.min_train_size, self.max_train_size, seq_len)

        X = torch.randn(batch_size, seq_len, self.max_features, device=self.device)

        if self.max_classes == 0:
            y = torch.randn(batch_size, seq_len, device=self.device)
        else:
            num_classes = np.random.randint(2, self.max_classes + 1)
            y = torch.randint(0, num_classes, (batch_size, seq_len), device=self.device)

        d = torch.full((batch_size,), self.max_features, device=self.device)
        seq_lens = torch.full((batch_size,), seq_len, device=self.device)
        train_sizes = torch.full((batch_size,), train_size, device=self.device)

        return X, y, d, seq_lens, train_sizes


class PriorDataset(IterableDataset):
    """Main dataset class that provides an infinite iterator over synthetic tabular datasets.

    Parameters
    ----------
    batch_size : int, default=256
        Total number of datasets to generate per batch.

    batch_size_per_gp : int, default=4
        Number of datasets per group, sharing similar characteristics.

    batch_size_per_subgp : int, optional
        Number of datasets per subgroup, with more similar causal structures.
        If None, defaults to batch_size_per_gp.

    min_features : int, default=2
        Minimum number of features per dataset.

    max_features : int, default=100
        Maximum number of features per dataset.

    max_classes : int, default=10
        Maximum number of target classes.

    min_seq_len : int, optional
        Minimum samples per dataset. If None, uses max_seq_len directly.

    max_seq_len : int, default=1024
        Maximum samples per dataset.

    log_seq_len : bool, default=False
        If True, sample sequence length from a log-uniform distribution.

    seq_len_per_gp : bool, default=False
        If True, sample sequence length per group, allowing variable-sized datasets.

    min_train_size : int or float, default=0.1
        Position or ratio for train/test split start. If int, absolute position.
        If float between 0 and 1, specifies a fraction of sequence length.

    max_train_size : int or float, default=0.9
        Position or ratio for train/test split end. If int, absolute position.
        If float between 0 and 1, specifies a fraction of sequence length.

    replay_small : bool, default=False
        If True, occasionally sample smaller sequence lengths with
        specific distributions to ensure model robustness on smaller datasets.

    prior_type : str, default="mlp_scm"
        Type of prior: 'mlp_scm' (default), 'tree_scm', 'mix_scm',
        'informed_scm', 'hybrid_scm', or 'dummy'.

        1. SCM-based: Structural causal models with complex feature relationships
         - 'mlp_scm': MLP-based causal models
         - 'tree_scm': Tree-based causal models
         - 'mix_scm': Probabilistic mix of the above models
         - 'informed_scm': SCM + informed block/coupling structure
         - 'hybrid_scm': Mix of generic and informed SCM samples

        2. Dummy: Randomly generated datasets for debugging

    informed_prior_ratio : float, default=0.5
        For 'hybrid_scm', probability of sampling an informed subgroup.

    scm_fixed_hp : dict, default=DEFAULT_FIXED_HP
        Fixed parameters for SCM-based priors.

    scm_sampled_hp : dict, default=DEFAULT_SAMPLED_HP
        Parameters sampled during generation.

    n_jobs : int, default=-1
        Number of parallel jobs to run (-1 means using all processors).

    num_threads_per_generate : int, default=1
        Number of threads per job for dataset generation.

    device : str, default="cpu"
        Computation device ('cpu' or 'cuda').
    """

    def __init__(
        self,
        batch_size: int = 256,
        batch_size_per_gp: int = 4,
        batch_size_per_subgp: Optional[int] = None,
        min_features: int = 2,
        max_features: int = 100,
        max_classes: int = 10,
        min_seq_len: Optional[int] = None,
        max_seq_len: int = 1024,
        log_seq_len: bool = False,
        seq_len_per_gp: bool = False,
        min_train_size: Union[int, float] = 0.1,
        max_train_size: Union[int, float] = 0.9,
        replay_small: bool = False,
        prior_type: str = "mlp_scm",
        scm_fixed_hp: Dict[str, Any] = DEFAULT_FIXED_HP,
        scm_sampled_hp: Dict[str, Any] = DEFAULT_SAMPLED_HP,
        n_jobs: int = -1,
        num_threads_per_generate: int = 1,
        informed_prior_ratio: float = 0.5,
        device: str = "cpu",
    ):
        super().__init__()
        if prior_type == "dummy":
            self.prior = DummyPrior(
                batch_size=batch_size,
                min_features=min_features,
                max_features=max_features,
                max_classes=max_classes,
                min_seq_len=min_seq_len,
                max_seq_len=max_seq_len,
                log_seq_len=log_seq_len,
                min_train_size=min_train_size,
                max_train_size=max_train_size,
                device=device,
            )
        elif prior_type in ["mlp_scm", "tree_scm", "mix_scm", "informed_scm", "hybrid_scm"]:
            self.prior = SCMPrior(
                batch_size=batch_size,
                batch_size_per_gp=batch_size_per_gp,
                batch_size_per_subgp=batch_size_per_subgp,
                min_features=min_features,
                max_features=max_features,
                max_classes=max_classes,
                min_seq_len=min_seq_len,
                max_seq_len=max_seq_len,
                log_seq_len=log_seq_len,
                seq_len_per_gp=seq_len_per_gp,
                min_train_size=min_train_size,
                max_train_size=max_train_size,
                replay_small=replay_small,
                prior_type=prior_type,
                fixed_hp=scm_fixed_hp,
                sampled_hp=scm_sampled_hp,
                n_jobs=n_jobs,
                num_threads_per_generate=num_threads_per_generate,
                informed_prior_ratio=informed_prior_ratio,
                device=device,
            )
        else:
            raise ValueError(
                "Unknown prior type "
                f"'{prior_type}'. Available options: 'mlp_scm', 'tree_scm', 'mix_scm', "
                "'informed_scm', 'hybrid_scm', or 'dummy'."
            )

        self.batch_size = batch_size
        self.batch_size_per_gp = batch_size_per_gp
        self.batch_size_per_subgp = batch_size_per_subgp or batch_size_per_gp
        self.min_features = min_features
        self.max_features = max_features
        self.max_classes = max_classes
        self.min_seq_len = min_seq_len
        self.max_seq_len = max_seq_len
        self.log_seq_len = log_seq_len
        self.seq_len_per_gp = seq_len_per_gp
        self.min_train_size = min_train_size
        self.max_train_size = max_train_size
        self.device = device
        self.prior_type = prior_type

    def get_batch(self, batch_size: Optional[int] = None) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
        """Generate a new batch of datasets.

        Parameters
        ----------
        batch_size : int, optional
            If provided, overrides the default batch size for this call.

        Returns
        -------
        X : Tensor or NestedTensor
            1. For SCM-based priors:
             - If seq_len_per_gp=False, shape is ``(batch_size, seq_len, max_features)``.
             - If seq_len_per_gp=True, returns a NestedTensor.

            2. For DummyPrior, random Gaussian values of
            ``(batch_size, seq_len, max_features)``.

        y : Tensor or NestedTensor
            1. For SCM-based priors:
             - If seq_len_per_gp=False, shape is ``(batch_size, seq_len)``.
             - If seq_len_per_gp=True, returns a NestedTensor.

            2. For DummyPrior, random class labels of ``(batch_size, seq_len)``.

        d : Tensor
            Number of active features per dataset of shape ``(batch_size,)``.

        seq_lens : Tensor
            Sequence length for each dataset of shape ``(batch_size,)``.

        train_sizes : Tensor
            Position for train/test split for each dataset of shape ``(batch_size,)``.
        """
        return self.prior.get_batch(batch_size)

    def __iter__(self) -> "PriorDataset":
        """Return an iterator that yields batches indefinitely.

        Returns
        -------
        self
            Returns self as an iterator.
        """
        return self

    def __next__(self) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
        """Return the next batch from the iterator.

        Since this is an infinite iterator, it never raises StopIteration
        and instead continuously generates new synthetic data batches.
        """
        with DisablePrinting():
            return self.get_batch()

    def __repr__(self) -> str:
        """Return a string representation of the dataset.

        Provides a detailed view of the dataset configuration for debugging
        and logging purposes.

        Returns
        -------
        str
            A formatted string with dataset parameters.
        """
        return (
            f"PriorDataset(\n"
            f"  prior_type: {self.prior_type}\n"
            f"  batch_size: {self.batch_size}\n"
            f"  batch_size_per_gp: {self.batch_size_per_gp}\n"
            f"  features: {self.min_features} - {self.max_features}\n"
            f"  max classes: {self.max_classes}\n"
            f"  seq_len: {self.min_seq_len or 'None'} - {self.max_seq_len}\n"
            f"  sequence length varies across groups: {self.seq_len_per_gp}\n"
            f"  train_size: {self.min_train_size} - {self.max_train_size}\n"
            f"  device: {self.device}\n"
            f")"
        )


class DisablePrinting:
    """Context manager to temporarily suppress printed output."""

    def __enter__(self):
        self.original_stdout = sys.stdout
        sys.stdout = open(os.devnull, "w")

    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.stdout.close()
        sys.stdout = self.original_stdout
